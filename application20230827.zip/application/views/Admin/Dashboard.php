

<!--**********************************

            Sidebar end

        ***********************************-->

<!--**********************************

            Content body start

        ***********************************-->

<div class="background1">

  <div style=" background: #80a3df4d; width:100%;

                 ">

    <div class="content-body">

      <div class="container-fluid mt-3">

        <div class="row">

          <div class="col-lg-3">

            <div class="text-white bg-primary mb-3" style="background-color: #495057!important; border-radius:10px;">

              <div class="card-body">

                <a href="<?php echo base_url('index.php/ManageAssets/ViewAssets');?>"><h3 class="card-title text-white">Total Registered Assets</h3>

                <div class="d-inline-block">
                  <h2 class="text-white"><?php if(!empty($Dashboard_count)){echo $Dashboard_count[0]['total_assets'];}else{echo "0";}?></h2>

                </div></a>

                <span class="float-right display-5 opacity-5">

                  <i class="fa fa-address-book"></i>

                </span>

              </div>

            </div>

          </div>

          <div class="col-lg-3">

            <div class="text-white bg-primary mb-3" style="background-color: #495057!important; border-radius:10px;">

              <div class="card-body">

                <a href="<?php echo base_url('index.php/ManageAssets/ViewsTempAssets');?>"><h3 class="card-title text-white">Total Temp Assets </h3>

                <div class="d-inline-block">

                  <h2 class="text-white"><?php if(!empty($Dashboard_count)){echo $Dashboard_count[0]['tempassets'];}else{echo "0";}?></h2>

                </div>
              </a>

                <span class="float-right display-5 opacity-5">

                  <i class="fa fa-industry"></i>

                </span>

              </div>

            </div>

          </div>

          
          <div class="col-lg-3">

            <div class="text-white bg-primary mb-3" style="background-color: #495057!important; border-radius:10px;">

              <div class="card-body">

                <a href="<?php echo base_url('index.php/Master/Asset_Type');?>"><h3 class="card-title text-white">Types Of Assets</h3>

                <div class="d-inline-block">

                  <h2 class="text-white"><?php if(!empty($Dashboard_count)){echo $Dashboard_count[0]['asset_types'];}else{echo "0";}?></h2>

                </div>
                </a>

                <span class="float-right display-5 opacity-5">

                  <i class="fa fa-shopping-cart"></i>

                </span>

              </div>

            </div>

          </div>
          <div class="col-lg-3">

            <div class="text-white bg-primary mb-3" style="background-color: #495057!important; border-radius:10px;">

              <div class="card-body">

                <a href="<?php echo base_url('index.php/Reports/DeletedAssets');?>"><h3 class="card-title text-white">Total Deleted Assets</h3>

                <div class="d-inline-block">
                  <h2 class="text-white"><?php if(!empty($Dashboard_count)){echo $Dashboard_count[0]['total_deletedassets'];}else{echo "0";}?></h2>

                </div>
                </a>

                <span class="float-right display-5 opacity-5">
                  <i class="fa fa-trash"></i>

                </span>

              </div>

            </div>

          </div>

        </div>

        </div>
        <div class="container-fluid mt-3">

        <div class="row">

          <!-- <div class="col-lg-3">

            <div class="text-white bg-primary mb-3" style="background-color: #495057!important; border-radius:10px;">

              <div class="card-body">

                <a href="<?php echo base_url('index.php/Reports/DeletedAssets');?>"><h3 class="card-title text-white">Total Deleted Assets</h3>

                <div class="d-inline-block">
                  <h2 class="text-white"><?php if(!empty($Dashboard_count)){echo $Dashboard_count[0]['total_deletedassets'];}else{echo "0";}?></h2>

                </div>
                </a>

                <span class="float-right display-5 opacity-5">
                  <i class="fa fa-trash"></i>

                </span>

              </div>

            </div>

          </div> -->

          
          <div class="col-lg-3">

            <div class="text-white bg-primary mb-3" style="background-color: #495057!important; border-radius:10px;">

              <div class="card-body">

                <a href="<?php echo base_url('index.php/Assets/TransferAssetList');?>"><h3 class="card-title text-white">Pending Transfer Request</h3>

                <div class="d-inline-block">

                  <h2 class="text-white"><?php if(!empty($Dashboard_count)){echo $Dashboard_count[0]['total_pending_transfer_request'];}else{echo "0";}?></h2>

                </div>
                </a>

                <span class="float-right display-5 opacity-5">

                  <i class="fa fa-clock-o"></i>

                </span>

              </div>

            </div>

          </div>

          <!-- <div class="col-lg-3">

            <div class="text-white bg-primary mb-3" style="background-color:#495057!important; border-radius:10px;">

              <div class="card-body">

                <h3 class="card-title text-white">Total Users</h3>

                <div class="d-inline-block">

                  <h2 class="text-white"><?php if(!empty($Dashboard_count)){echo $Dashboard_count[0]['users'];}else{echo "0";}?></h2>

                </div>

                <span class="float-right display-5 opacity-5">

                  <i class="fa fa-users"></i>

                </span>

              </div>

            </div>

          </div> -->

          <!-- <div class="col-lg-3">

            <div class="text-white bg-primary mb-3" style="background-color: #495057!important; border-radius:10px;">

              <div class="card-body">

                <h3 class="card-title text-white">Types Of Assets</h3>

                <div class="d-inline-block">

                  <h2 class="text-white"><?php if(!empty($Dashboard_count)){echo $Dashboard_count[0]['asset_types'];}else{echo "0";}?></h2>

                </div>

                <span class="float-right display-5 opacity-5">

                  <i class="fa fa-shopping-cart"></i>

                </span>

              </div>

            </div>

          </div> -->

        </div>

        </div>

      </div>

      <!-- #/ container -->




    </div>

  </div>

</div>

<!--**********************************

            Content body end

        ***********************************-->

<!--**********************************

            Footer start

***********************************--> 
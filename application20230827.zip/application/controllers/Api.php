<?php 

class API extends CI_Controller
{
	public function __construct(){
			parent::__construct();
			$this->load->model('API_Model', 'API_Model');
		}

	function Login(){
		if(!empty($_POST['username']) && !empty($_POST['password'])){
		$username = $_POST['username'];
		$password = md5($_POST['password']);
		}

		if (!empty($username) && !empty($password)) {
			$result = $this->API_Model->Match_Password($username,$password);
			if (!empty($result)) {
				print_r(json_encode(array("data"=>$result)));
				
			}else{
				echo json_encode(array("data"=>"No Match User Details !"));
				//echo json_encode("No Match User Details");
			}
		}else{
			echo json_encode(array("data"=>"Enter username and password !"));
			//echo json_encode("Enter username and password");
		}
		
	}

	function Asset_Type_Master(){
		if (!empty($result = $this->API_Model->Get_Asset_Type())) {
		print_r(json_encode(array("data"=>$result)));
		}else{
		echo json_encode(array("data"=>"No Data Found !"));
		}
	}

	function Category_Master(){
		if (!empty($result = $this->API_Model->Get_Category())) {
		print_r(json_encode(array("data"=>$result)));
		}else{
		echo json_encode(array("data"=>"No Data Found !"));
		}
	}
	function SubCategory_Master(){
		if (!empty($result = $this->API_Model->Get_SubCategory())) {
		print_r(json_encode(array("data"=>$result)));
		}else{
		echo json_encode(array("data"=>"No Data Found !"));
		}
	}

	function Plant_Master(){
	//$result = $this->API_Model->Get_Plant();
	if (!empty($result = $this->API_Model->Get_Plant())) {
		print_r(json_encode(array("data"=>$result)));
		//print_r(json_encode($result,JSON_PRETTY_PRINT));
	}else{
		echo json_encode(array("data"=>"No Data Found !"));
		//echo json_encode("No Match User Details");
	}
		
	}


	function Dept_Master(){
	//$result = $this->API_Model->Get_Plant();
	if (!empty($result = $this->API_Model->Get_Dept())) {
		print_r(json_encode(array("data"=>$result)));
		//print_r(json_encode($result,JSON_PRETTY_PRINT));
	}else{
		echo json_encode(array("data"=>"No Data Found !"));
		//echo json_encode("No Match User Details");
	}
		
	}

function Location_Master(){
	//$result = $this->API_Model->Get_Plant();
	if (!empty($result = $this->API_Model->Get_Location())) {
		print_r(json_encode(array("data"=>$result)));
		//print_r(json_encode($result,JSON_PRETTY_PRINT));
	}else{
		echo json_encode(array("data"=>"No Data Found !"));
		//echo json_encode("No Match User Details");
	}
		
	}


	function Get_Assets_Data(){

		$department = $_POST['department'];
		$location = $_POST['location'];
		$asset_type = $_POST['asset_type'];
		$cat = $_POST['cat'];
		$Assetsubcategory = $_POST['Assetsubcategory'];
		$accetcode = $_POST['asset_code'];
		if (!empty($result = $this->API_Model->Get_Assets($department,$location,$asset_type,$cat,$Assetsubcategory,$accetcode))){
			print_r(json_encode(array("msg"=>"Found","data"=>$result)));
			//print_r(json_encode($result,JSON_PRETTY_PRINT));
		}else{
			//echo json_encode(array("data"=>"No Data Found !"));
			print_r(json_encode(array("msg"=>" Not Found","data"=>$result)));
			//echo json_encode(array("msg"=>"No Data Found !"));
			//echo json_encode("No Match User Details");
		}
	}


	function Post_Inventry_Data(){
		header('Content-Type: application/json');
		$jeson = file_get_contents('php://input');
		$data = json_decode($jeson,true);
		/*$jeson = json_decode(file_get_contents('php://input'), true);
		$data =  json_encode($jeson);*/
		//echo $data;
		$inv_id = "INV".date('Ymdhms').rand(00000,10000);
		$blogtags = array();
		foreach ($data['scan_data'] as $row) {			
			$id = $row['id'];

			// Get Asset byid
			$Assetdetail = $this->API_Model->GetAssetByid($id);
			$tagid = $row['tag_id'];
			$scan_status = $row['scan_status'];
			$scan_by = $data['user_name'];
			$location_name = $data['location_name'];
			$dep_name = $data['dep_name'];
			$total = $data['total'];
			$found = $data['found'];
			$notfound = $data['notfound'];
			$scan_time = $data['scan_date_time'];

			$detailinv[] = array(            
			    'tag_id'=>$row['tag_id'],
			    'asset_name'=>$Assetdetail->asset_name,
			    'value'=>$Assetdetail->value, 
			    'invoice_no'=>$Assetdetail->invoice_no,
			    'facility'=>$Assetdetail->facility,
			    'region'=>$Assetdetail->region,
			    'city'=>$Assetdetail->city, 
			    'date_of_commissioning'=>$Assetdetail->date_of_commissioning,
			    'Specification'=>$Assetdetail->Specification,
			    'equipment_brand'=>$Assetdetail->equipment_brand,
			    'asset_code'=>$Assetdetail->asset_code, 
			    'date_of_installation'=>$Assetdetail->date_of_installation,
			    'warranty'=>$Assetdetail->warranty,
			    'asset_type'=>$Assetdetail->type_name,
			    'cat'=>$Assetdetail->cat,
			    'department'=>$Assetdetail->dep_name,
			    'model'=>$Assetdetail->model,
			    'device_sl_no'=>$Assetdetail->device_sl_no, 
			    'location'=>$Assetdetail->location_name,
			    'vendor'=>$Assetdetail->vendor, 
			    'po_no'=>$Assetdetail->po_no,
			    'asset_user'=>$Assetdetail->asset_user,
			    'Assetsubcategory'=>$Assetdetail->Assetsubcategory,
			    'asset_status'=>$Assetdetail->status_name, 
			    'UNIQUEID'=>$Assetdetail->UNIQUEID,
			    'Remarks'=>$Assetdetail->Remarks,
			    'scan_status'=>$scan_status,
			    'scan_by'=>$scan_by, 
			    'scan_at'=>$scan_time,
			    'inventry_id'=>$inv_id, 
			        
			    );
		}

		$mstinv = array(
			'inventry_id' => $inv_id,
			'location_name' => $data['location_name'],
			'dep_name' => $data['dep_name'],
			'total' => $data['total'], 
			'found' => $data['found'],
			'notfound' => $data['notfound'],
			'user_name' => $data['user_name'],
			'created_by' => $data['user_name'],
			'inventary_date' => $data['scan_date_time']
		);

		if ((!empty($mstinv)) && (!empty($detailinv)) ) {
			$this->db->insert('mst_inventry',$mstinv);
			$this->db->insert_batch('inventry_log',$detailinv);
			echo json_encode(array("data"=>" Sucess!"));
		}else{
			echo json_encode(array("data"=>" no input found or list is empty !"));
		}

    	}


    	function Scan_Data(){
    		if (!empty($tag_is = $_GET['tagid'])) {
			if (!empty($result = $this->API_Model->Get_Identify_Data($tag_is))) {
				print_r(json_encode(array("msg"=>"Found","data"=>$result)));
				//print_r(json_encode($result,JSON_PRETTY_PRINT));
			}else{
				//echo json_encode(array("data"=>"No Data Found !"));
				print_r(json_encode(array("msg"=>" Not Found","data"=>$result)));
				//echo json_encode(array("msg"=>"No Data Found !"));
				//echo json_encode("No Match User Details");
			}
		}else{
			//print_r(json_encode(array("data"=>$result)));
			echo json_encode(array("msg"=>" No Input Found !"));
			}
    	}



    	function Get_Tagdata(){
    		if (!empty($tid = $_GET['tagid'])) {
			if (!empty($result = $this->API_Model->Get_Tagdata($tid))) {
				print_r(json_encode(array("msg"=>"Found","data"=>$result)));
				//print_r(json_encode($result,JSON_PRETTY_PRINT));
			}else{
				//echo json_encode(array("data"=>"No Data Found !"));
				print_r(json_encode(array("msg"=>" Not Found","data"=>$result)));
				//echo json_encode(array("msg"=>"No Data Found !"));
				//echo json_encode("No Match User Details");
			}
		}else{
			//print_r(json_encode(array("data"=>$result)));
			echo json_encode(array("msg"=>" No Input Found !"));
			}
    	}

    	function Post_Temp_TransferData(){
    		header('Content-Type: application/json');
			$jeson = file_get_contents('php://input');
			$data = json_decode($jeson,true);
			if (!empty($data['id']) && empty($this->API_Model->Check_transfer_log($data['tagid'],$data['sourceplant']))) {
				$logdata = array(
                  'tagid' => $data['tagid'],
                  'asset_id' => $data['id'],
                  'asset_code' => $data['asset_code'],
                  'UNIQUEID' => $data['UNIQUEID'],
                  'source_plant' => $data['sourceplant'],
                  'source_dept' => $data['sourcedept'], 
                  'dest_plant' => $data['destinationplant'],
                  'desc_dept' => $data['descdept'],
                  'created_by' => $data['transferby']
                  );
                if($this->API_Model->Add_TransferTemp($logdata) == TRUE){
					echo json_encode(array("msg"=>"Done"));
                }else{
                	echo json_encode(array("msg"=>"Insertion Error !"));
                }
			}else{
				echo json_encode(array("msg"=>"Duplicate Entry !"));
			}
    	}

    	function Get_Temp_Tagdata(){
    		if (!empty($plant = trim($_GET['plant']))) {
			if (!empty($result = $this->API_Model->Get_Temp_Tagdata($plant))) {
				print_r(json_encode(array("msg"=>"Found","data"=>$result)));
				//print_r(json_encode($result,JSON_PRETTY_PRINT));
			}else{
				//echo json_encode(array("data"=>"No Data Found !"));
				print_r(json_encode(array("msg"=>" Not Found","data"=>$result)));
				//echo json_encode(array("msg"=>"No Data Found !"));
				//echo json_encode("No Match User Details");
			}
		}else{
			//print_r(json_encode(array("data"=>$result)));
			echo json_encode(array("msg"=>" No Input Found !"));
			}
    	}

    	function Send_Asset_Temp_to_trans(){
    		header('Content-Type: application/json');
			$jeson = file_get_contents('php://input');
			$data = json_decode($jeson,true);
			
			if (!empty($data['updatedby'])) {
				$blogtags = array();
				foreach ($data['datas'] as $row) {
					if(empty($row['tagid'])){
						$row['tagid'] = "0";
					}
					$blogtags[] = array(
					'id'=>$row['id'],     
				    'tag_id'=>$row['tagid'],
				    'created_by'=> $data['updatedby']   
				    ); 
				    $id[] = $row['id'];
				}
				$ids =  implode(',',$id);
				if($this->db->update_batch('temp_assets', $blogtags,'id') && $this->API_Model->PostData_temp_to_trans($ids)){
					echo json_encode(array("msg"=>"Done !"));
				}else{
					echo json_encode(array("msg"=>"Ids Not Found !"));
				}
				
			}else{
				echo json_encode(array("msg"=>" No Input Found !"));
			}

    	}

    function Get_Approved_Asset(){
    	if ( (!empty($tagid = trim($_POST['tagid']))) && (!empty($readerid = trim($_POST['readerid']))) ) {
			if (!empty($result = $this->API_Model->Get_approve_transfer_asset($tagid)) ) {
				print_r(json_encode(array("msg"=>"Found","data"=>$result)));
				//print_r(json_encode($result,JSON_PRETTY_PRINT));
			}else{										
				print_r(json_encode(array("msg"=>" Not Found","data"=>$result)));
			}
			$outlog = array(
				'tag_id'=>$_POST['tagid'],     
				'reader_id'=>$_POST['readerid'],
				'action'=> "OUT");
			$this->db->insert('out_gate_log', $outlog);
		}else{
			//print_r(json_encode(array("data"=>$result)));
			echo json_encode(array("msg"=>" No Input Found tagid and readerid !"));
			}
    }
function Get_Inventory_list(){
		if (!empty($department = $_POST['department']) && !empty($location = $_POST['location'])) {
			if (!empty($result = $this->API_Model->Get_Invlist($department,$location))) {
				print_r(json_encode(array("msg"=>"Found","data"=>$result)));
				//print_r(json_encode($result,JSON_PRETTY_PRINT));
			}else{
				//echo json_encode(array("data"=>"No Data Found !"));
				print_r(json_encode(array("msg"=>" Not Found","data"=>$result)));
				//echo json_encode(array("msg"=>"No Data Found !"));
				//echo json_encode("No Match User Details");
			}
		}else{
			print_r(json_encode(array("data"=>$result)));
			echo json_encode(array("msg"=>" Not Found !"));
		}
	}
}

?>
<?php 
class Bulk_upload_model extends CI_Model
{
	
}
?>
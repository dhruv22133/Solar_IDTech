<?php
class Auth_Model extends CI_MODEL {

	Function Mathc_Password($data){
		$query = $this->db->get_where('users', array('user_name' => $data['user_name'],'status'=>'1'));
		if ($query->num_rows() == 0){
			return false;
		}else{

		//Compare the password attempt with the password we have stored.
			$result = $query->row_array();
			if((MD5($data['password']))== $result['password']){
				return $result = $query->row_array();
			}else{
				return FALSE;
			}
		}

	}

	function Dashboard_count($plant,$usertype){
		if ($usertype == '1') {
			$query = $this->db->query("SELECT (SELECT COUNT(*) FROM mst_assets WHERE delete_atatus = '0' AND plant = '".$plant."')AS total_assets,
		(SELECT COUNT(*) FROM temp_assets WHERE plant = '".$plant."')AS tempassets,
		(SELECT COUNT(*) FROM users WHERE plant = '".$plant."')AS users,
		(SELECT COUNT(*) FROM mst_asset_type)AS asset_types,
		(SELECT COUNT(*) FROM mst_assets WHERE delete_atatus = '1' AND plant = '".$plant."')AS total_deletedassets,
		(SELECT COUNT(*) FROM asset_transfer_log AS t1
		LEFT JOIN `mst_assets` AS t2 ON t1.tagid = t2.tag_id
		WHERE t1.status = '0')AS total_pending_transfer_request");
		return $query->result_array();
		}else{
			$query = $this->db->query("SELECT (SELECT COUNT(*) FROM mst_assets WHERE delete_atatus = '0' AND plant = '".$plant."')AS total_assets,
		(SELECT COUNT(*) FROM temp_assets WHERE plant = '".$plant."')AS tempassets,
		(SELECT COUNT(*) FROM users WHERE plant = '".$plant."')AS users,
		(SELECT COUNT(*) FROM mst_asset_type)AS asset_types,
		(SELECT COUNT(*) FROM mst_assets WHERE delete_atatus = '1' AND plant = '".$plant."')AS total_deletedassets,
		(SELECT COUNT(*) FROM asset_transfer_log AS t1
		LEFT JOIN `mst_assets` AS t2 ON t1.tagid = t2.tag_id
		WHERE t1.status = '0' AND t2.plant = '".$plant."')AS total_pending_transfer_request");
		return $query->result_array();
		}
		
	}

}



?>
<!--**********************************

            Sidebar end

        ***********************************-->

<!--**********************************

            Content body start

        ***********************************-->

<div class="content-body">

 <div class="row page-titles mx-0">

    <div class="col p-md-0">

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="javascript:void(0)">Dashboard</a>

        </li>

        <li class="breadcrumb-item">

          <a href="javascript:void(0)">Manage Asset</a>

        </li>

        <li class="breadcrumb-item active">

          <a href="javascript:void(0)">View Assets</a>

        </li>

      </ol>

    </div>

  </div>

  <!-- row -->

  <div class="ViewAssets">

    <div class="container-fluid">

      <div class="row">

        <div class="col-12">

          <div class="card">

            <div class="col-lg-12 bg-primary text-white" style="background-color:#1168f9!important;">

              <div class="card-header">View Assets</div>

            </div>

            <div class="card-body">

              <div class="table-responsive" style="overflow-x:auto; ">

                <table id="example" class=" table-striped table-bordered zero-configuration">

                  <thead>
                    <tr>
                      <th>Id</th>
                      <th>Tag Id</th>
                      <th>Finance Asset Id</th>
                      <th>It Asset Code</th>
                      <th>Asset Type</th>
                      <th>Sbu</th>
                      <th>Asset Class Code</th>
                      <th>Asset Class Name</th>
                      <th>Asset Sub Class</th>
                      <th>Location</th>
                      <th>Plant</th>
                      <th>Department</th>
                      <th>Make/Oem</th>
                      <th>Model</th>
                      <th>Device Serial No</th>
                      <th>Asset Status</th>
                      <th>Vendor</th>
                      <th>Quantity</th>
                      <th>Cost Center</th>
                      <th>Po Number</th>
                      <th>Description</th>
                      <!-- <th>Wdv</th> -->
                      <th>Month & Year Of Purchase</th>
                      <th>Capitalized On</th>
                      <th>Asset User</th>
                      <th>Created By</th>
                      <th>Created At</th>
                    </tr>

                  </thead>

                  <tfoot>

                    <tr>
                      <th>Id</th>
                      <th>Tag Id</th>
                      <th>Finance Asset Id</th>
                      <th>It Asset Code</th>
                      <th>Asset Type</th>
                      <th>Sbu</th>
                      <th>Asset Class Code</th>
                      <th>Asset Class Name</th>
                      <th>Asset Sub Class</th>
                      <th>Location</th>
                      <th>Plant</th>
                      <th>Department</th>
                      <th>Make/Oem</th>
                      <th>Model</th>
                      <th>Device Serial No</th>
                      <th>Asset Status</th>
                      <th>Vendor</th>
                      <th>Quantity</th>
                      <th>Cost Center</th>
                      <th>Po Number</th>
                      <th>Description</th>
                      <!-- <th>Wdv</th> -->
                      <th>Month & Year Of Purchase</th>
                      <th>Capitalized On</th>
                      <th>Asset User</th>
                      <th>Created By</th>
                      <th>Created At</th>
                    </tr>

                  </tfoot>

                  <tbody>

                    <?php  $count=1;

                      if(!empty($assets)){
                        //print_r($assets);
                        foreach($assets as $row){ ?>

                      <tr>
                        <td><?= $count; ?></td>
                        <td><?= $row['tag_id']; ?></td>
                        <td><?= $row['finance_asset_id']; ?></td>
                        <td><?= $row['it_asset_code']; ?></td>
                        <td><?= $row['type_name']; ?></td>
                        <td><?= $row['sbu']; ?></td>
                        <td><?= $row['asset_class_code']; ?></td>
                        <td><?= $row['asset_class_name']; ?></td>
                        <td><?= $row['asset_sub_class']; ?></td>
                        <td><?= $row['location_name']; ?></td>
                        <td><?= $row['plant_name']; ?></td>
                        <td><?= $row['dep_name']; ?></td>
                        <td><?= $row['make_oem']; ?></td>
                        <td><?= $row['model']; ?></td>
                        <td><?= $row['device_sl_no']; ?></td>
                        <td><?= $row['status_name']; ?></td>
                        <td><?= $row['vendor']; ?></td>
                        <td><?= $row['quantity']; ?></td>
                        <td><?= $row['cost_center']; ?></td>
                        <td><?= $row['po_no']; ?></td>
                        <td><?= $row['description']; ?></td>
                        <!-- <td><?= $row['wdv']; ?></td> -->
                        <td><?= $row['purchase_date']; ?></td>
                        <td><?= $row['capitalized_on']; ?></td>
                        <td><?= $row['asset_user']; ?></td>
                        <td><?= $row['created_by']; ?></td>
                        <td><?= $row['created_at']; ?></td>
                        </tr>
                        <?php $count++; }} ?>
                      </tbody>

                </table>

              </div>

            </div>

          </div>

        </div>

      </div>

    </div>

  </div>

  <!-- #/ container -->

</div>

<!--**********************************

            Content body end

        ***********************************-->

<!--**********************************

            Footer start

        ***********************************--> 
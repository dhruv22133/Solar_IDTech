<!--**********************************

            Sidebar end

        ***********************************-->
<!--**********************************

            Content body start

        ***********************************-->
<link href='<?= base_url() ?>assets/Dropdown_smartseatch/jquery-3.2.1.min.js' rel='stylesheet' type='text/css'>
<script src='<?= base_url() ?>assets/Dropdown_smartseatch/select2/dist/js/select2.min.js' type='text/javascript'></script>
<link href='<?= base_url() ?>assets/Dropdown_smartseatch/select2/dist/css/select2.min.css' rel='stylesheet' type='text/css'>
<div class="content-body">
  <div class="row page-titles mx-0">
    <div class="col p-md-0">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"> <a href="javascript:void(0)">Dashboard</a> </li>
        <li class="breadcrumb-item"> <a href="javascript:void(0)">Manage Assets</a> </li>
        <li class="breadcrumb-item active"> <a href="javascript:void(0)">Mapp Temp Assets</a> </li>
      </ol>
    </div>
  </div>
  <!-- row -->
  <div class="backgroundassetsRegis">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="col-lg-12 bg-primary text-white" style="background-color:#1168f9!important;">
              <div class="card-header">Temp Asset</div>
            </div>
            <div class="card-body">
              <div class="basic-form">
                <?php if(isset($msg) || validation_errors() !== ''): ?>
                  <div class="alert alert-danger alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <h4><i class="icon fa fa-warning"></i> Alert !</h4>
                    <?= validation_errors();?>
                      <?= isset($msg)? $msg: ''; ?>
                  </div>
                  <?php endif; ?>
              <?php if($this->session->flashdata('msg') != ''): ?>
            <div class="alert alert-success flash-msg alert-dismissible">
              <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
              <h4> Success !</h4>
              <?= $this->session->flashdata('msg'); ?>
            </div>
            <?php endif; ?>
              <?php if($this->session->flashdata('faliour') != ''): ?>
                <div class="alert alert-danger flash-msg alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4> Error !</h4>
                  <?= $this->session->flashdata('msg'); ?>
                </div>
                <?php endif; ?>
                <form action="<?php echo base_url('index.php/Assets/Search_TempAsset');?>" method="POST">
                  <div class="form-group row">
                    <label class="col-sm-1 col-form-label"> <b>Finance Id</b> </label>
                    <div class="col-sm-5">
                      <select name="financeid"  id="financeid" class="form-control input-rounded">
                        <option value="">Select Finance Id</option>
                        <?php if($Finance_List){ foreach ($Finance_List as $financecode){?>
                          <option value="<?php echo $financecode['finance_asset_id'] ?>" <?php if(!empty($finance) && $financecode['finance_asset_id'] ==$finance ){echo "selected";}?>><?php echo $financecode['finance_asset_id']; ?></option>
                          <?php }} ?>
                        </select>
                    </div>
                      <label class="col-sm-1.5 col-form-label"> <b>It Asset Code</b> </label>
                    <div class="col-sm-4">
                      <select name="itasset"  id="itasset" class="form-control input-rounded">
                        <option value="">Select It Asset Code</option>
                        <?php if($ItAssetCode_List){ foreach ($ItAssetCode_List as $itcode){?>
                          <option value="<?php echo $itcode['it_asset_code'] ?>" <?php if(!empty($itcode) && $itcode['it_asset_code'] ==$itcode ){echo "selected";}?>><?php echo $itcode['it_asset_code']; ?></option>
                          <?php }} ?>
                        </select>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-sm-10">
                      <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12">
          <div class="card">
            <div class="col-lg-12 bg-primary text-white" style="background-color:#1168f9!important;">
              <div class="card-header"></div>
            </div>
            <script>
            function doconfirm() {
              job = confirm("Are you sure to delete Location permanently?");
              if(job != true) {
                return false;
              }
            }

            function docedit() {
              job = confirm("Are you sure to Edit Location asset ?");
              if(job != true) {
                return false;
              }
            }
            </script>
            <div class="card-body">
              <div class="table-responsive" style="overflow-x:auto; ">
                <table id="example" class=" table-striped table-bordered zero-configuration">
                  <thead>
                    <tr>
                      <th>Sl No.</th>
                      <th>Finance Id</th>
                      <th>IT Asset Code</th>
                      <th>Department </th>
                      <th>Asset User</th>
                      <th>Description</th>
                      <th>Asset Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tfoot>
                    <tr>
                      <th>Sl No.</th>
                      <th>Finance Id</th>
                      <th>IT Asset Code</th>
                      <th>Department </th>
                      <th>Asset User</th>
                      <th>Description</th>
                      <th>Asset Status</th>
                      <th>Action</th>
                    </tr>
                  </tfoot>
                  <tbody>
                    <?php  $count=1;

                    if(!empty($assetdata)){

                    foreach($assetdata as $loc){ ?>
                      <tr>
                        <td><?= $count; ?></td>
                        <td><?= $loc['finance_asset_id']; ?></td>
                        <td><?= $loc['it_asset_code']; ?></td>
                        <td><?= $loc['dep_name']; ?></td>
                        <td><?= $loc['asset_user']; ?></td>
                        <td><?= $loc['description']; ?></td>
                        <td><?= $loc['status_name']; ?></td>
                        <td>
                          <!-- <a href="<?= base_url('#'.$loc['id']); ?>">
                            <button class="btn btn-danger" onClick="return doconfirm();"><i class="glyphicon glyphicon-trash"></i> <i class="fa fa-trash-o "></i> Delete </button>
                          </a> -->
                          <a href="<?= base_url('index.php/Assets/AddTidTempasset/'.$loc['id']); ?>">
                            <button class="btn btn-info" onClick="return docedit();"><i class="glyphicon glyphicon-trash"></i> <i class="fa fa-edit "></i> Mapp With Tag </button>
                          </a>
                        </td>
                      </tr>
                      <?php $count++; }} ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- #/ container -->
</div>
<script type="text/javascript">
$("#financeid").select2();
$("#itasset").select2();
</script>
<!--**********************************

            Content body end

        ***********************************-->
<!--**********************************

            Footer start

        ***********************************-->
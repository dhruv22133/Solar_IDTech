<!--**********************************

            Sidebar end

        ***********************************-->

<!--**********************************

            Content body start

        ***********************************-->

<div class="content-body">

  <div class="row page-titles mx-0">

    <div class="col p-md-0">

      <ol class="breadcrumb">

        <li class="breadcrumb-item">

          <a href="javascript:void(0)">Dashboard</a>

        </li>

        <li class="breadcrumb-item">

          <a href="javascript:void(0)">ManageAsset</a>

        </li>

        <li class="breadcrumb-item active">

          <a href="javascript:void(0)">Asset Registration</a>

        </li>

      </ol>

    </div>

  </div>

  <!-- row -->

  <div class="ViewAssets">

    <div class="container-fluid">

      <div class="row justify-content-center">

        <div class="col-lg-12">

          <div class="card">

            <div class="col-lg-12 bg-primary text-white" style="background-color:#1168f9!important;">

              <div class="card-header">Asset Registration</div>

            </div>

            <div class="card-body">

              <div class="form-validation">

                <?php if(isset($msg) || validation_errors() !== ''): ?>

                  <div class="alert alert-danger alert-dismissible">

                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                      <h4><i class="icon fa fa-warning"></i> Alert !</h4>

                      <?= validation_errors();?>

                      <?= isset($msg)? $msg: ''; ?>

                  </div>

                <?php endif; ?>

              <?php if($this->session->flashdata('msg') != ''): ?>

                  <div class="alert alert-success flash-msg alert-dismissible">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                    <h4> Success !</h4>

                    <?= $this->session->flashdata('msg'); ?> 

                  </div>

                <?php endif; ?>



                <?php if($this->session->flashdata('faliour') != ''): ?>

                  <div class="alert alert-danger flash-msg alert-dismissible">

                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>

                    <h4> Error !</h4>

                    <?= $this->session->flashdata('msg'); ?> 

                  </div>

                <?php endif; ?> 



                <form class="form-valide" action="<?php echo base_url('index.php/ManageAssets/RegisterAssets');?>" method="post">

                  <div class="row">

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-username">

                          <b>Non Tagable Assets</b>

                        </label>

                        <div class="col-sm-8">

                          <div class="form-check">

                            <input class="form-check-input" id="non-tagable-assets" type="checkbox" name="non-tagable-assets" value="1">

                          </div>

                        </div>

                      </div>

                    </div>

                    <div class="col-lg-6">

                      <div class="form-group row" id="tag_id">

                        <label class="col-lg-4 col-form-label" for="val-username">

                          <b>Tag Id</b>

                        </label>

                        <div class="col-lg-6">

                          <input type="text" name="tag_id" class="form-control input-rounded" placeholder="" value="<?php echo set_value('tag_id'); ?>" placeholder="Enter Tag ID">

                        </div>

                      </div>

                    </div>

                  </div>

                  <div class="row">

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-username">

                          <b>Finance Asset Id</b>

                        </label>

                        <div class="col-lg-6">

                          <input type="text" class="form-control input-rounded" name="finance_asset_id" value="<?php echo set_value('finance_asset_id'); ?>" id="val-username" name="val-username" placeholder="Finance Asset Id.." required>

                        </div>

                      </div>

                    </div>

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-username">

                          <b>IT Asset Code </b>

                        </label>

                        <div class="col-lg-6">

                          <input type="text" class="form-control input-rounded" name="it_asset_code" value="<?php echo set_value('it_asset_code'); ?>" placeholder="IT Asset Code.." required>

                        </div>

                      </div>

                    </div>

                  </div>

                  <div class="row">

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-skill">

                          <b>Select Asset Status</b>

                        </label>

                        <div class="col-lg-6">

                          <select name="asset_status"  id="asset_status" class="form-control" required>

                            <option value="">Select Asset Status</option>

                            <?php if($status){ foreach ($status as $statusts){?>

                            <option value="<?php echo $statusts['id'] ?>"><?php echo $statusts['status_name']; ?></option>

                            <?php }} ?>

                          </select>

                        </div>

                      </div>

                    </div>

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-username">

                          <b>Asset Description</b>

                        </label>

                        <div class="col-lg-6">

                          <input type="text" class="form-control input-rounded" id="description" value="<?php echo set_value('description'); ?>" name="description" placeholder="Asset Description.." required>

                        </div>

                      </div>

                    </div>

                  </div>

                  <div class="row">

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-skill">

                          <b>Select Asset Type</b>

                        </label>

                        <div class="col-lg-6">

                          <select name="Assettype" class="form-control input-rounded" id="Assettype">

                          <option value="">Select Asset Type</option>

                          <?php if($asset_type){ foreach ($asset_type as $assets){?>

                          <option value="<?php echo $assets['id']; ?>"><?php echo $assets['type_name']; ?></option>

                          <?php }} ?>

                        </select>

                        </div>

                      </div>

                    </div>

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-skill">

                          <b>Select Asset Class</b>

                        </label>

                        <div class="col-lg-6">

                          <select name="Assetclass"  id="Assetclass" class="form-control input-rounded" required>

                            <option value="">Select Asset Class</option>

                            <?php if($AssetClass){ foreach ($AssetClass as $assclass){?>

                            <option value="<?php echo $assclass['id']; ?>"><?php echo $assclass['asset_class_code']."/".$assclass['asset_class_name']; ?></option>

                            <?php }} ?>

                          </select>

                        </div>

                      </div>

                    </div>

                  </div>

                  <div class="row">

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-username">

                          <b>Asset Sub Class</b>

                        </label>

                        <div class="col-lg-6">

                          <input type="text" class="form-control input-rounded" name="asset_subclass" value="<?php echo set_value('asset_subclass'); ?>"  placeholder="Asset Sub Class..">

                        </div>

                      </div>

                    </div>

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-username">

                          <b>Model</b>

                        </label>

                        <div class="col-lg-6">

                          <input type="text" class="form-control input-rounded" name="model" value="<?php echo set_value('model'); ?>" placeholder="Model..">

                        </div>

                      </div>

                    </div>

                  </div>

                  <div class="row">

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-username">

                          <b>Device Serial No</b>

                        </label>

                        <div class="col-lg-6">

                          <input type="text" class="form-control input-rounded" name="device_sl_no" value="<?php echo set_value('device_sl_no'); ?>" placeholder="Device Serial No..">

                        </div>

                      </div>

                    </div>

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-username">

                          <b>Make/Oem</b>

                        </label>

                        <div class="col-lg-6">

                          <input type="text" class="form-control input-rounded" name="make_oem" value="<?php echo set_value('make_oem'); ?>" placeholder="Enter Make/Oem..">

                        </div>

                      </div>

                    </div>

                  </div>

                  <div class="row">

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-username">

                          <b>S B U </b>

                        </label>

                        <div class="col-lg-6">

                          <input type="text" class="form-control input-rounded" value="<?php echo set_value('sbu'); ?>" name="sbu" placeholder="Enter S B U." required>

                        </div>

                      </div>

                    </div>

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-skill">

                          <b>Capitalized On</b>

                        </label>

                        <div class="col-lg-6">

                          <div class="input-group ">

                            <input type="text" class="form-control mydatepicker input-rounded" name="Capitalized" value="<?php echo set_value('Capitalized'); ?>" placeholder="mm/dd/yyyy" required>

                            <span class="input-group-append">

                              <span class="input-group-text">

                                <i class="mdi mdi-calendar-check"></i>

                              </span>

                            </span>

                          </div>

                        </div>

                      </div>

                    </div>

                  </div>

                  <div class="row">

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-skill">

                          <b>Select Plant</b>

                        </label>

                        <div class="col-lg-6">

                          <select name="plant" id="plant" class="form-control" required>

                            <option value="">Select Plant</option>

                            <?php if($plants){ foreach ($plants as $plant){?>

                            <option value="<?php echo $plant['id'] ?>"><?php echo $plant['plant_name']; ?></option>

                            <?php }} ?>

                          </select>

                        </div>

                      </div>

                    </div>

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-skill">

                          <b>Select Department</b>

                        </label>

                        <div class="col-lg-6">

                          <select name="department" id="department" class="form-control" required>

                            <option value="">Select Department</option>

                            <?php if($depts){ foreach ($depts as $dept){?>

                            <option value="<?php echo $dept['id'] ?>"><?php echo $dept['dep_name']; ?></option>

                            <?php }} ?>

                          </select>

                        </div>

                      </div>

                    </div>

                  </div>

                  <div class="row">

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-skill">

                          <b>Location</b>

                        </label>

                        <div class="col-lg-6">

                          <select name="location" id="locationsel" class="form-control" required>

                            <option value="">Select Location</option>

                            <?php if($locations){ foreach ($locations as $loc){?>

                            <option value="<?php echo $loc['id'] ?>"><?php echo $loc['location_name']; ?></option>

                            <?php }} ?>

                          </select>

                        </div>

                      </div>

                    </div>

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-username">

                          <b>Asset User Name</b>

                        </label>

                        <div class="col-lg-6">

                          <input type="text" class="form-control input-rounded" name="asset_user" value="<?php echo set_value('asset_user'); ?>" placeholder="Asset User Name..">

                        </div>

                      </div>

                    </div>

                  </div>

                  <div class="row">

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-skill">

                          <b>Select Cost Center</b>

                        </label>

                        <div class="col-lg-6">

                          <select name="cost_center" class="form-control" id="costcenter" required>

                            <option value="">Select Cost Center</option>

                            <?php if($costcenter){ foreach ($costcenter as $cost_centerr){?>

                            <option value="<?php echo $cost_centerr['cost_center_name'] ?>"><?php echo $cost_centerr['cost_center_name']; ?></option>

                            <?php }} ?>

                          </select>

                        </div>

                      </div>

                    </div>

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-username">

                          <b>Po Number</b>

                        </label>

                        <div class="col-lg-6">

                          <input type="text" class="form-control input-rounded" id="po_no" name="po_no" value="<?php echo set_value('po_no'); ?>" placeholder="Po Number..">

                        </div>

                      </div>

                    </div>

                  </div>

                  <div class="row">

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-username">

                          <b>Vendor </b>

                        </label>

                        <div class="col-lg-6">

                          <input type="text" class="form-control input-rounded" id="vendor" name="vendor" value="<?php echo set_value('vendor'); ?>" placeholder="Enter Vendor..">

                        </div>

                      </div>

                    </div>

                    <div class="col-lg-6">

                      <div class="form-group row">

                        <label class="col-lg-4 col-form-label" for="val-username">

                          <b>Quantity </b>

                        </label>

                        <div class="col-lg-6">

                          <input type="text" class="form-control input-rounded" id="quantity" name="quantity" value="<?php echo set_value('quantity'); ?>" placeholder="Enter Quantity.." required>

                        </div>

                      </div>

                    </div>

                  </div>

                  <div class="row">

                    <div class="col-lg-12">

                      <div class="form-group row">

                        <label class="col-lg-2 col-form-label" for="val-username">

                          <b>Month & Year of purchase</b>

                        </label>

                        <div class="col-lg-9">

                          <div class="input-group">

                            <input type="text" class="form-control mydatepicker input-rounded" name="purchase_date" value="<?php echo set_value('purchase_date'); ?>" placeholder="mm/dd/yyyy">

                            <span class="input-group-append">

                              <span class="input-group-text">

                                <i class="mdi mdi-calendar-check"></i>

                              </span>

                            </span>

                          </div>

                        </div>

                      </div>

                    </div>

                  </div>

                  <div class="form-group row">

                    <div class="col-lg-8 ml-auto">

                      <button type="submit" name="submit" class="btn btn-primary">Submit</button>

                    </div>

                  </div>

                </form>

              </div>

            </div>

          </div>

        </div>

      </div>

    </div>

  </div>

  <!-- #/ container -->

</div>

<div class="container">

  <!-- row -->

  <!-- #/ container -->

</div>

<!--**********************************

            Content body end

        ***********************************-->

<!--**********************************

            Footer start

        ***********************************--> 



<script>

// hide tag id on click non tagable asset 



$("#non-tagable-assets").on('click', function(){



    $("#tag_id").toggle();



})



// Smart Dropdown search

$("#Assettype").select2();

$("#Assetclass").select2();

$("#department").select2();

$("#plant").select2();

$("#locationsel").select2();

$("#asset_status").select2();

$("#costcenter").select2();

</script> 
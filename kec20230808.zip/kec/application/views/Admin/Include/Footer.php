<div class="footer" style=" position: absolute;
        right: 0;
        bottom: 0;
        left: 0;
        padding: 0rem;
        background-color: #efefef;
        text-align: center;">
            <div class="copyright">
                <p>Copyright &copy; 2021 All rights reserved <a href="#"> ID Tech  Solution Pvt. Ltd.</a></p>
            </div>
        </div>
        <!--**********************************
            Footer end
        ***********************************-->
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <script src="<?php echo base_url('assets/');?>plugins/common/common.min.js"></script>
    <script src="<?php echo base_url('assets/');?>js/custom.min.js"></script>
    <script src="<?php echo base_url('assets/');?>js/settings.js"></script>
    <script src="<?php echo base_url('assets/');?>js/gleek.js"></script>
    <script src="<?php echo base_url('assets/');?>js/styleSwitcher.js"></script>

    <script src="<?php echo base_url('assets/');?>plugins/validation/jquery.validate.min.js"></script>
    <script src="<?php echo base_url('assets/');?>plugins/validation/jquery.validate-init.js"></script>


 <script src="<?php echo base_url('assets/');?>plugins/moment/moment.js"></script>
    <script src="<?php echo base_url('assets/');?>plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>
    <!-- Clock Plugin JavaScript -->
    <script src="<?php echo base_url('assets/');?>plugins/clockpicker/dist/jquery-clockpicker.min.js"></script>
    <!-- Color Picker Plugin JavaScript -->
    <script src="<?php echo base_url('assets/');?>plugins/jquery-asColorPicker-master/libs/jquery-asColor.js"></script>
    <script src="<?php echo base_url('assets/');?>plugins/jquery-asColorPicker-master/libs/jquery-asGradient.js"></script>
    <script src="<?php echo base_url('assets/');?>plugins/jquery-asColorPicker-master/dist/jquery-asColorPicker.min.js"></script>
    <!-- Date Picker Plugin JavaScript -->
    <script src="<?php echo base_url('assets/');?>plugins/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <!-- Date range Plugin JavaScript -->
    <script src="<?php echo base_url('assets/');?>plugins/timepicker/bootstrap-timepicker.min.js"></script>
    <script src="<?php echo base_url('assets/');?>plugins/bootstrap-daterangepicker/daterangepicker.js"></script>

    <script src="<?php echo base_url('assets/');?>js/plugins-init/form-pickers-init.js"></script>


    
    <script type="text/javascript" src="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.js"></script>


  <script src="<?php echo base_url('assets/');?>plugins/tables/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo base_url('assets/');?>plugins/tables/js/datatable/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo base_url('assets/');?>plugins/tables/js/datatable-init/datatable-basic.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/r/dt/jq-2.1.4,jszip-2.5.0,pdfmake-0.1.18,dt-1.10.9,af-2.0.0,b-1.0.3,b-colvis-1.0.3,b-html5-1.0.3,b-print-1.0.3,se-1.0.1/datatables.min.js"></script>


       <!-- Chartjs -->
    <script src="<?php echo base_url('assets/');?>plugins/chart.js/Chart.bundle.min.js"></script>
    <!-- Circle progress -->
    <script src="<?php echo base_url('assets/');?>plugins/circle-progress/circle-progress.min.js"></script>
    <!-- Datamap -->
    <script src="<?php echo base_url('assets/');?>plugins/d3v3/index.js"></script>
    <script src="<?php echo base_url('assets/');?>plugins/topojson/topojson.min.js"></script>
    <script src="<?php echo base_url('assets/');?>plugins/datamaps/datamaps.world.min.js"></script>
    <!-- Morrisjs -->
    <script src="<?php echo base_url('assets/');?>plugins/raphael/raphael.min.js"></script>
    <script src="<?php echo base_url('assets/');?>plugins/morris/morris.min.js"></script>
    <!-- Pignose Calender -->
    <script src="<?php echo base_url('assets/');?>plugins/moment/moment.min.js"></script>
    <script src="<?php echo base_url('assets/');?>plugins/pg-calendar/js/pignose.calendar.min.js"></script>
    <!-- ChartistJS -->
    <script src="<?php echo base_url('assets/');?>plugins/chartist/js/chartist.min.js"></script>
    <script src="<?php echo base_url('assets/');?>plugins/chartist-plugin-tooltips/js/chartist-plugin-tooltip.min.js"></script>


<--- DASHBOARD -->
    <script src="<?php echo base_url('assets/');?>js/dashboard/dashboard-1.js"></script>


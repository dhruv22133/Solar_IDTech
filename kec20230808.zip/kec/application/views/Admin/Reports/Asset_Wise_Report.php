
<!--**********************************
            Sidebar end
        ***********************************-->
<!--**********************************
            Content body start
        ***********************************-->
<div class="content-body">
  <div class="row page-titles mx-0">
    <div class="col p-md-0">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="javascript:void(0)">Dashboard</a>
        </li>
        <li class="breadcrumb-item">
          <a href="javascript:void(0)">Reports</a>
        </li>
        <li class="breadcrumb-item active">
          <a href="javascript:void(0)">Asset Wise Report</a>
        </li>
      </ol>
    </div>
  </div>
  <!-- row -->
  <div class="backgroundassetsRegis">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <div class="card">
            <div class="col-lg-12 bg-primary text-white" style="background-color:#1168f9!important;">
              <div class="card-header">Asset Wise Report</div>
            </div>
            <div class="card-body">
              <div class="basic-form">
                <form action="<?php echo base_url('index.php/Reports/AssetWise');?>" method="POST">
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="val-username">
                          <b>Tag Id</b>
                        </label>
                        <div class="col-lg-6">
                          <input type="text" class="form-control input-rounded" name="tagid" value="<?php echo set_value('tagid'); ?>" placeholder="Enter Tag Id..">
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="val-username">
                          <b>It Asset Code</b>
                        </label>
                        <div class="col-lg-6">
                          <input type="text" class="form-control input-rounded" value="<?php echo set_value('itasset_code'); ?>" name="itasset_code" placeholder="Enter Tag Id..">
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="val-username">
                          <b>Finance Asset Id</b>
                        </label>
                        <div class="col-lg-6">
                          <input type="text" name="financeid" class="form-control input-rounded" id="financeid" value="<?php echo set_value('financeid'); ?>" placeholder="Enter Finance Asset ID..">
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="val-skill">
                          <b>Asset Type</b>
                        </label>
                        <div class="col-lg-6">
                          <select name="Assettype" class="form-control input-rounded" id="Assettype">
                            <option value="">Select Asset Type</option>
                            <?php if($asset_type){ foreach ($asset_type as $assets){?>
                            <option value="<?php echo $assets['id']; ?>" <?php if(!empty($Assettype) && $assets['id'] == $Assettype){ echo "selected"; }?>><?php echo $assets['type_name']; ?></option>
                            <?php }} ?>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="val-skill">
                          <b>Asset Class</b>
                        </label>
                        <div class="col-lg-6">
                          <select name="Assetclass"  id="Assetclass" class="form-control input-rounded">
                            <option value="">Select Asset Class</option>
                            <?php if($AssetClass){ foreach ($AssetClass as $assclass){?>
                            <option value="<?php echo $assclass['id']; ?>" <?php if(!empty($Assetclass) && $assclass['id'] == $Assetclass){ echo "selected"; }?> ><?php echo $assclass['asset_class_code']."/".$assclass['asset_class_name']; ?></option>
                            <?php }} ?>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="val-skill">
                          <b>Department</b>
                        </label>
                        <div class="col-lg-6">
                          <select name="department" id="department" class="form-control input-rounded">
                            <option value="">Select Department</option>
                            <?php if($depts){ foreach ($depts as $dept){?>
                            <option value="<?php echo $dept['id'] ?>" <?php if(!empty($department) && $dept['id'] == $department){ echo "selected"; }?> ><?php echo $dept['dep_name']; ?></option>
                            <?php }} ?>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="val-skill">
                          <b>Select Plant</b>
                        </label>
                        <div class="col-lg-6">
                          <select name="plant" id="plant" class="form-control input-rounded">
                            <option value="">Select Plant</option>
                            <?php if($plants){ foreach ($plants as $plant){?>
                            <option value="<?php echo $plant['id'] ?>" <?php if(!empty($plantaa) && $plant['id'] == $plantaa){ echo "selected"; }?> ><?php echo $plant['plant_name']; ?></option>
                            <?php }} ?>
                          </select>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="val-skill">
                          <b>Location</b>
                        </label>
                        <div class="col-lg-6">
                          <select name="location" id="locationsel" class="form-control input-rounded">
                            <option value="">Select Location</option>
                            <?php if($locations){ foreach ($locations as $loc){?>
                            <option value="<?php echo $loc['id'] ?>" <?php if(!empty($location) && $loc['id'] == $location){ echo "selected"; }?> ><?php echo $loc['location_name']; ?></option>
                            <?php }} ?>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="val-skill">
                          <b>Cost Center</b>
                        </label>
                        <div class="col-lg-6">
                          <select name="cost_center" class="form-control input-rounded" id="cost_center">
                              <option value="">Select Cost Center</option>
                              <?php if($costcenter){ foreach ($costcenter as $cost_centerr){?>
                              <option value="<?php echo $cost_centerr['id'] ?>" <?php if(!empty($cost_center) && $cost_centerr['id'] == $cost_center){ echo "selected"; }?> ><?php echo $cost_centerr['cost_center_name']; ?></option>
                              <?php }} ?>
                            </select>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="val-skill">
                          <b>Asset Status</b>
                        </label>
                        <div class="col-lg-6">
                          <select name="asset_status"  id="asset_status" class="form-control input-rounded">
                            <option value="">Select Asset Status</option>
                            <?php if($status){ foreach ($status as $statusts){?>
                            <option value="<?php echo $statusts['id'] ?>" <?php if(!empty($asset_status) &&  $statusts['id'] == $asset_status){ echo "selected"; }?> ><?php echo $statusts['status_name']; ?></option>
                            <?php }} ?>
                          </select>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="val-username">
                          <b>From Date</b>
                        </label>
                        <div class="col-lg-6">
                          <div class="input-group">
                            <input type="text" class="form-control mydatepicker input-rounded" name="frome" value="<?php echo set_value('frome'); ?>" placeholder="mm/dd/yyyy" required>
                            <span class="input-group-append">
                              <span class="input-group-text">
                                <i class="mdi mdi-calendar-check"></i>
                              </span>
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group row">
                        <label class="col-lg-4 col-form-label" for="val-skill">
                          <b>To Date</b>
                        </label>
                        <div class="input-group col-lg-6">
                          <input type="text" class="form-control mydatepicker input-rounded" name="todate" value="<?php echo set_value('todate'); ?>" placeholder="mm/dd/yyyy" required>
                          <span class="input-group-append">
                            <span class="input-group-text">
                              <i class="mdi mdi-calendar-check"></i>
                            </span>
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-sm-10">
                      <button type="submit" name="submit" class="btn btn-primary">Submit</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div class="col-12">
          <div class="card">
            <div class="col-lg-12 bg-primary text-white" style="background-color:#1168f9!important;">
              <div class="card-header"></div>
            </div>
            <div class="card-body">
              <div class="table-responsive" style="overflow-x:auto; ">
                <table id="example" class=" table-striped table-bordered zero-configuration">
                  <thead>
                    <tr>
                     <th>Id</th>
                      <th>Tag Id</th>
                      <th>Asset Type</th>
                      <th>Finance Asset Id</th>
                      <th>Sbu</th>
                      <th>Asset Class Code</th>
                      <th>Asset Class Name</th>
                      <th>Asset Sub Class</th>
                      <th>Department</th>
                      <th>Plant</th>
                      <th>Make/Oem</th>
                      <th>Model</th>
                      <th>Device Serial No</th>
                      <th>Asset Status</th>
                      <th>Location</th>
                      <th>Vendor</th>
                      <th>Quantity</th>
                      <th>IT Asset ID</th>
                      <th>Cost Center</th>
                      <th>Po Number</th>
                      <th>Description</th>
                      <th>Month & Year Of Purchase</th>
                      <th>Capitalized On</th>
                      <th>Asset User</th>
                      <th>Created By</th>
                      <th>Created At</th>
                  </tr>
                  </thead>
                  <tfoot>
                    <tr>
                     <th>Id</th>
                      <th>Tag Id</th>
                      <th>Asset Type</th>
                      <th>Finance Asset Id</th>
                      <th>Sbu</th>
                      <th>Asset Class Code</th>
                      <th>Asset Class Name</th>
                      <th>Asset Sub Class</th>
                      <th>Department</th>
                      <th>Plant</th>
                      <th>Make/Oem</th>
                      <th>Model</th>
                      <th>Device Serial No</th>
                      <th>Asset Status</th>
                      <th>Location</th>
                      <th>Vendor</th>
                      <th>Quantity</th>
                      <th>IT Asset ID</th>
                      <th>Cost Center</th>
                      <th>Po Number</th>
                      <th>Description</th>
                      <th>Month & Year Of Purchase</th>
                      <th>Capitalized On</th>
                      <th>Asset User</th>
                      <th>Created By</th>
                      <th>Created At</th>
                  </tr>
                  </tfoot>
                  <tbody>
                    <?php  $count=1;
                        if(!empty($assetdata)){
                        foreach($assetdata as $row){ ?>
                        <tr>
                          <td><?= $count; ?></td>
                          <td><?= $row['tag_id']; ?></td>
                          <td><?= $row['type_name']; ?></td>
                          <td><?= $row['finance_asset_id']; ?></td>
                          <td><?= $row['sbu']; ?></td>
                          <td><?= $row['asset_class_code']; ?></td>
                          <td><?= $row['asset_class_name']; ?></td>
                          <td><?= $row['asset_sub_class']; ?></td>
                          <td><?= $row['dep_name']; ?></td>
                          <td><?= $row['plant_name']; ?></td>
                          <td><?= $row['make_oem']; ?></td>
                          <td><?= $row['model']; ?></td>
                          <td><?= $row['device_sl_no']; ?></td>
                          <td><?= $row['status_name']; ?></td>
                          <td><?= $row['location_name']; ?></td>
                          <td><?= $row['vendor']; ?></td>
                          <td><?= $row['quantity']; ?></td>
                          <td><?= $row['it_asset_code']; ?></td>
                          <td><?= $row['cost_center']; ?></td>
                          <td><?= $row['po_no']; ?></td>
                          <td><?= $row['description']; ?></td>
                          <td><?= $row['purchase_date']; ?></td>
                          <td><?= $row['capitalized_on']; ?></td>
                          <td><?= $row['asset_user']; ?></td>
                          <td><?= $row['created_by']; ?></td>
                          <td><?= $row['created_at']; ?></td>
                        </tr>
                        <?php $count++; }} ?>

                </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- #/ container -->
</div>
<!--**********************************
            Content body end
        ***********************************-->
<!--**********************************
            Footer start
        ***********************************-->
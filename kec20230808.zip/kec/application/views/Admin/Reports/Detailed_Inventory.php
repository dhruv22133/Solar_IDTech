<div class="content-body">
  <div class="row page-titles mx-0">
    <div class="col p-md-0">
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="javascript:void(0)">Dashboard</a>
        </li>
        <li class="breadcrumb-item">
          <a href="javascript:void(0)">Reports</a>
        </li>
        <li class="breadcrumb-item active">
          <a href="javascript:void(0)">Physical inventry report</a>
        </li>
      </ol>
    </div>
  </div>
  <!-- row -->
  <div class="backgroundassetsRegis">
    <div class="container-fluid">
      <div class="row">        
        </div>
        <div class="col-12">
          <div class="card">
            <div class="col-lg-12 bg-primary text-white" style="background-color:#1168f9!important;">
              <div class="card-header"><a href="<?php echo base_url('index.php/Report/Mst_Inv');?>"> <button style="margin-bottom: 10px" class="btn btn-danger"><i class="fa fa-arrow-left"></i> Back</button></a></div>
            </div>
            <div class="card-body">
              <div class="table-responsive" style="overflow-x:auto; ">
                <table id="example" class=" table-striped table-bordered zero-configuration">
                  <thead>
                    <tr>
                     <th>Sl.No</th>
                      <th>Tag Id</th>
                      <th>IT Asset Code</th>
                      <th>Finance Asset Id</th>
                      <th>Department</th>
                      <th>Description</th>
                      <th>Asset User Name</th>
                      <th>Asset Status</th>
                      <th>Scan Status</th>
                      <th>Scan Time</th>
                  </tr>
                  </thead>
                  <tfoot>
                    <tr>
                     <th>Sl.No</th>
                      <th>Tag Id</th>
                      <th>IT Asset Code</th>
                      <th>Finance Asset Id</th>
                      <th>Department</th>
                      <th>Description</th>
                      <th>Asset User Name</th>
                      <th>Asset Status</th>
                      <th>Scan Status</th>
                      <th>Scan Time</th>
                  </tr>
                  </tfoot>
                  <tbody>
                    <?php  $count=1;
                        if(!empty($Inventry)){
                        foreach($Inventry as $row){ ?>
                        <tr>
                          <td><?= $count; ?></td>
                          <td><?= $row['tag_id']; ?></td>
                          <td><?= $row['it_asset_code']; ?></td>
                          <td><?= $row['finance_asset_id']; ?></td>
                          <td><?= $row['depname']; ?></td>
                          <td><?= $row['description']; ?></td>
                          <td><?= $row['asset_user']; ?></td>
                          <td><?= $row['status_name']; ?></td>
                          <td><?= $row['scan_status']; ?></td>
                          <td><?= $row['scan_time']; ?></td>
                        </tr>
                        <?php $count++; }} ?>

                </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- #/ container -->
</div>
<!--**********************************
            Content body end
        ***********************************-->
<!--**********************************
            Footer start
        ***********************************-->

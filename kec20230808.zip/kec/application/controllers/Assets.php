<?php
class Assets extends CI_Controller
{
  public function __construct(){
        parent::__construct();
        $this->isLogin = $this->session->userdata('user_logged');
        $this->load->model('Asset_Model', 'Asset_Model');
        $this->load->model('Master_Model', 'Master_Model');
        $this->load->model('API_Model', 'API_Model');
        $this->load->model('User_Model', 'User_Model');
        if(!$this->isLogin){
        redirect(base_url('index.php/Auth/Logout'));
        }
    }

  function Asset_Reg(){
    $data['asset_type'] = $this->Master_Model->Get_Asset_Type();
    $data['depts'] = $this->Master_Model->Get_Dep();
    $data['plants'] = $this->Master_Model->Get_Plant();
    $data['status'] = $this->Master_Model->Get_Status();
    $data['locations'] = $this->Master_Model->Get_Location();
    $data['AssetClass'] = $this->Master_Model->Get_AssetClass();
    $data['costcenter'] = $this->Master_Model->Get_CostCenter();
    if (isset($_POST['submit'])) {
      $this->form_validation->set_rules('Assettype',' Asset Type','trim');
      //$this->form_validation->set_rules('asset_primary_code',' Asset Primary Code','trim|required');
      $this->form_validation->set_rules('finance_asset_id',' Finance Asset Id','trim|required');
      if (!empty($_POST['non-tagable-assets']) && $_POST['non-tagable-assets'] == "1") {
        //$this->form_validation->set_rules('tag_id',' Tag Id','trim|required|is_unique[mst_assets.tag_id]');
        $_POST['tag_id'] = $_POST['finance_asset_id']."1234567"."NON_TAG";
      }
      $this->form_validation->set_rules('asset_user',' Asset User Name','trim');
      $this->form_validation->set_rules('sbu',' SBU','trim|required');
      $this->form_validation->set_rules('Assetclass',' Asset Class','trim|required');
      //$this->form_validation->set_rules('asset_class_2',' Asset Class 2','trim|required');
      $this->form_validation->set_rules('asset_subclass',' Asset Subclass','trim');
      $this->form_validation->set_rules('department',' Department','trim|required');
      $this->form_validation->set_rules('plant',' Plant','trim|required');
      $this->form_validation->set_rules('make_oem',' Make Oem','trim');
      $this->form_validation->set_rules('model',' Model','trim');
      $this->form_validation->set_rules('device_sl_no',' Device Sl No','trim');
      //$this->form_validation->set_rules('status',' Status','trim|required');
      $this->form_validation->set_rules('location',' Location','trim|required');
      $this->form_validation->set_rules('vendor',' Vendor','trim');
      $this->form_validation->set_rules('quantity',' Quantity','trim|required');
      $this->form_validation->set_rules('it_asset_code',' It Asset Code','trim|required|is_unique[mst_assets.it_asset_code]');
      $this->form_validation->set_rules('cost_center',' Cost Center','trim|required');
      $this->form_validation->set_rules('po_no',' PO Number','trim');
      $this->form_validation->set_rules('description',' Description','trim|required');
      $this->form_validation->set_rules('asset_status',' Asset Status','trim|required');
      $this->form_validation->set_rules('purchase_date',' Purchase Date','trim');
      $this->form_validation->set_rules('Capitalized',' Capitalized','trim|required');
                      
            if ($this->form_validation->run()== TRUE) {
                $userdata = array(
                            'asset_type' => $_POST['Assettype'],
                            //'asset_primary_code' => $_POST['asset_primary_code'],
                            'tag_id' => $_POST['tag_id'],
                            'asset_user' => $_POST['asset_user'],
                            'finance_asset_id' => $_POST['finance_asset_id'],
                            'sbu' => $_POST['sbu'],
                            'asset_class_1' => $_POST['Assetclass'],
                            'asset_class_2' => $_POST['Assetclass'],
                            'asset_sub_class' => $_POST['asset_subclass'],
                            'department' => $_POST['department'],
                            'plant' => $_POST['plant'], 
                            'make_oem' => $_POST['make_oem'],
                            'model' => $_POST['model'],
                            'device_sl_no' => $_POST['device_sl_no'],
                            //'form_status' => $_POST['status'],
                            'location' => $_POST['location'],
                            'vendor' => $_POST['vendor'],
                            'quantity' => $_POST['quantity'],
                            'it_asset_code' => $_POST['it_asset_code'],
                            'cost_center' => $_POST['cost_center'],
                            'po_no' => $_POST['po_no'],
                            'description' => $_POST['description'],
                            'asset_status' => $_POST['asset_status'],
                            'purchase_date' => $_POST['purchase_date'],
                            'capitalized_on' => $_POST['Capitalized'],
                            'created_by' => $_SESSION['email'],
                            'creation_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Asset_Model->Asset_Registration($userdata) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Added Successfully!');
                    redirect(base_url('ManageAssets/RegisterAssets'));
                }else{
                    $this->session->set_flashdata('msg', ' Insertion Error !');
                    redirect(base_url('ManageAssets/RegisterAssets'));
                }

            }else{
              $this->template->load('template', 'Admin/Manage_Assets/Asset_Registration',$data);
            }
    }else{
    $this->template->load('template', 'Admin/Manage_Assets/Asset_Registration',$data);
    }
  }




  function View_Assets(){
    $loc = $_SESSION['plant'];
    $usertype = $_SESSION['user_type'];
    $data['assets'] = $this->Asset_Model->Get_Assets($loc,$usertype);
    $this->template->load('template', 'Admin/Manage_Assets/View_Assets',$data);
  }

  function View_Temp_Assets(){
    $loc = $_SESSION['plant'];
    $id = $_SESSION['user_type'];
    $data['privilledge'] = $this->User_Model->Get_Privilledge_list($id);
    $data['assets'] = $this->Asset_Model->Get_Temp_Assets($loc,$id);
    $this->template->load('template', 'Admin/Manage_Assets/Temp_Assets',$data);
  }

  Function Edit_Asset($id){
      $data['id'] = $id;
      $data['asset_type'] = $this->Master_Model->Get_Asset_Type();
      $data['depts'] = $this->Master_Model->Get_Dep();
      $data['plants'] = $this->Master_Model->Get_Plant();
      $data['status'] = $this->Master_Model->Get_Status();
      $data['locations'] = $this->Master_Model->Get_Location();
      $data['AssetClass'] = $this->Master_Model->Get_AssetClass();
      $data['costcenter'] = $this->Master_Model->Get_CostCenter();
      $data['assetdata'] = $this->Asset_Model->Get_Assets_byid($id);
      if (isset($_POST['submit'])) {
      $this->form_validation->set_rules('assetstatus',' Asset Status','trim|required');
      $this->form_validation->set_rules('asset_desc',' Asset Description','trim|required');
      $this->form_validation->set_rules('model',' Model','trim|required');
      $this->form_validation->set_rules('device_sl_no',' Device Sl No','trim');
      $this->form_validation->set_rules('make_oem',' Make/Oem','trim|required');
      $this->form_validation->set_rules('sbu',' S B U','trim');
      $this->form_validation->set_rules('capitilazetion_on',' Capitalized On','trim|required');
      $this->form_validation->set_rules('plant',' Plant','trim|required');
      $this->form_validation->set_rules('department',' Department','trim|required');
      $this->form_validation->set_rules('location',' Location','trim|required');
      $this->form_validation->set_rules('asset_user',' Asset User','trim');
      $this->form_validation->set_rules('cost_center',' Cost Center','trim|required');
      $this->form_validation->set_rules('po_no',' PO No','trim');
      $this->form_validation->set_rules('vendor',' Vendor','trim');
      $this->form_validation->set_rules('quantity',' It Asset Code','trim');
      $this->form_validation->set_rules('purchase_date',' Purchase Date','trim');
                           
            if ($this->form_validation->run()== TRUE) {
                $userdata = array(
                  'asset_status' => $_POST['assetstatus'],
                  'asset_user' => $_POST['asset_user'],
                  'sbu' => $_POST['sbu'],
                  'department' => $_POST['department'],
                  'plant' => $_POST['plant'], 
                  'make_oem' => $_POST['make_oem'],
                  'model' => $_POST['model'],
                  'device_sl_no' => $_POST['device_sl_no'],
                  'location' => $_POST['location'],
                  'vendor' => $_POST['vendor'],
                  'quantity' => $_POST['quantity'],
                  'cost_center' => $_POST['cost_center'],
                  'po_no' => $_POST['po_no'],
                  'wdv' => $_POST['wdv_value'],
                  'description' => $_POST['asset_desc'],
                  'purchase_date' => $_POST['purchase_date'],
                  'capitalized_on' => $_POST['capitilazetion_on'],
                  'updated_at' => date('Y-m-d h:m:s'),
                  'updated_by' => $_SESSION['email'],
                  'updation_ip' => getenv("REMOTE_ADDR")
                  );
                if($this->Asset_Model->Update_asset($userdata,$id) == TRUE){
                    $this->session->set_flashdata('msg', ' Asset is Updated Successfully!');
                    redirect(base_url('ManageAssets/ManageAsset'));
                }else{
                    $this->session->set_flashdata('msg', ' Updation Error !');
                    redirect(base_url('ManageAssets/ManageAsset'));
                }
            }else{
              $this->template->load('template', 'Admin/Manage_Assets/Edit_Assets',$data);
            }
      }else{
      $this->template->load('template', 'Admin/Manage_Assets/Edit_Assets',$data);
      }
      
    }

  function Manage_Assets(){
    $loc = $_SESSION['plant'];
    $id = $_SESSION['user_type'];
    $data['privilledge'] = $this->User_Model->Get_Privilledge_list($id);
    if (isset($_POST['submit'])) {
      //$tag_id = $_POST['tagid'];
      $data['assets'] = $this->Asset_Model->Get_Assets_search(trim($_POST['tagid']),$loc,$id);
      $this->template->load('template', 'Admin/Manage_Assets/Manage_Assets',$data);
    }else{
    $data['assets'] = $this->Asset_Model->Get_Assets($loc,$id);
    $this->template->load('template', 'Admin/Manage_Assets/Manage_Assets',$data);
    }
  }

  Function Delete_Asset($id){
    $log = array(
                    'asset_id' => $id,
                    'type' => "Asset Deletion",
                    'source' => "ManageAssets/DeleteAssets/".$id,
                    'deletion_by' => $_SESSION['email'],
                    'ip' => getenv("REMOTE_ADDR"),
                    'description' => "Delete Asset");

        if($this->Asset_Model->Remove_log($log) == TRUE && $this->Asset_Model->Remove_Assets($id)){
      $this->session->set_flashdata('msg', ' Record is Deleted Successfully!');
      redirect(base_url('ManageAssets/ManageAsset'));
    }else{
      $this->session->set_flashdata('msg', ' Deletion Error !');
      redirect(base_url('ManageAssets/ManageAsset'));
    }
  }

  Function Transfer_Asset($id){
    if (isset($_POST['submit'])) {
      //print_r($_POST);
      $assetdata = $this->Asset_Model->Get_Assets_byid($id);
      $loc = $_POST['desc_loc'];
      $plant = $_POST['desc_plant'];
      $userdata = array(
                    'tagid' => $assetdata[0]['tag_id'],
                    'asset_id' => $assetdata[0]['id'],
                    'source_loc' => $assetdata[0]['loc_name'],
                    'source_plant' => $assetdata[0]['plant_name'],
                    'destination_loc' => $_POST['desc_loc'],
                    'dest_plant' => $_POST['desc_plant'],
                    'created_by' => $_SESSION['email'],
                    'creation_ip' => getenv("REMOTE_ADDR"));
      if($this->Asset_Model->Asset_Asset_Transfer_log($userdata) == TRUE && $this->Asset_Model->Transfer_mst_asset($id,$loc,$plant)){
      $this->session->set_flashdata('msg', ' Asset Transfer Successfully!');
      redirect(base_url('ManageAssets/Asset_Transfer/'.$id));
      }else{
        $this->session->set_flashdata('msg', ' Transection Error !');
        redirect(base_url('ManageAssets/Asset_Transfer/'.$id));
      }

    }else{
    $data['id'] = $id;
    $data['locations'] = $this->Master_Model->Get_Location();
    $data['asset_details'] = $this->Asset_Model->Get_Assets_byid($id);
    $data['plants'] = $this->Master_Model->Get_Plant();
        $this->load->view('admin/Manage_Assets/Asset_Transfer',$data);
      }
  }


  function Bulk_Upload_Assets(){
    $this->template->load('template', 'Admin/Manage_Assets/Bulk_Upload');
  }

  // Bulk Upload 

  function Asset_Registration_bulk(){
      $ip = $_SERVER['REMOTE_ADDR'];
      $by = $_SESSION['email'];
      ini_set('max_execution_time', 0); 
      ini_set('memory_limit', '-1');
      if (isset($_POST['submit'])) {
        $file = $_FILES['bulk_upload']['tmp_name'];
        $type = explode(".",$_FILES['bulk_upload']['name']);
        if(strtolower(end($type)) == 'csv'){
        $handle = fopen($file, "r");
              $c = 1;//
              while(($filesop = fgetcsv($handle, 10000, ",")) !== false)
              {
                $finance_asset_code = $filesop[0];
                $Asset_type = $filesop[1];
                $asset_class_id = $filesop[2];
                $assetsubclass = $filesop[3];
                $sbu = $filesop[4];
                $plant = $filesop[5];
                $dept = $filesop[6];
                $asset_user = $filesop[7];
                $captelization_on =date("Y-m-d", strtotime($filesop[8]));
                $cost_center = $filesop[9];
                $desc = $filesop[10];
                $make_oem = $filesop[11];
                $model = $filesop[12];
                $deviceslno = $filesop[13];
                $source_loc = $filesop[14];
                $vender = $filesop[15];
                $quantity = $filesop[16];
                $pono = $filesop[17];
                $purchase_date = date("Y-m-d", strtotime($filesop[18]));
                $itassetcode = $filesop[19];
                $statusid = $filesop[20];
                  if($c<>1){
                  //if (empty($this->Auth_Model->MatchTID($tagid))) {
                    $values[] = "('$finance_asset_code','$Asset_type','$asset_class_id','$assetsubclass','$sbu','$plant','$dept','$asset_user','$captelization_on','$cost_center','$desc','$make_oem','$model','$deviceslno','$source_loc','$vender','$quantity','$pono','$purchase_date','$itassetcode','$statusid','$by','$ip')";
                  //}else{
                  //}
                  
                  
                  }

                  $c = $c + 1;

                  
              }
              if (!empty($values)) {
                try{
                    $formdata =  implode(',',$values);
                    $quary = "INSERT INTO `temp_assets` (`finance_asset_id`,`asset_type`, `asset_class_1`,`asset_sub_class`,`sbu`,`plant`,`department`,`asset_user`,`capitalized_on`,`cost_center`,`description`,`make_oem`,`model`,`device_sl_no`,`location`,`vendor`,`quantity`,`po_no`,`purchase_date`,`it_asset_code`,`asset_status`,`created_by`,`creation_ip`) VALUES $formdata;";
                    if ($this->Asset_Model->Ass_Bulk_date($quary) == TRUE) {
                      $this->session->set_flashdata('msg',' Successfully Uploded Asset Data!');
                      redirect('index.php/ManageAssets/BulkUpload');
                     }else{
                      $this->session->set_flashdata('faliour',' Insertion Error !');
                    redirect('index.php/ManageAssets/BulkUpload');
                     }
                 }catch (Exception $e) {
                     echo $e;
                  }
                  }
              }else{
                $this->session->set_flashdata('failure',' File format is not match. Only .CSV format allowed. you try to upload :- '.strtolower(end($type)) ." file that is wrong format !");
                  redirect('index.php/Assets/Bulk_Upload_Assets');
              }

              
      }else{
      redirect('index.php/Assets/Bulk_Upload_Assets');
      }
    }

    Function Delete_Temp_Asset($id){
      if($this->Asset_Model->Remove_temp_Assets($id)){
        $this->session->set_flashdata('msg', ' Record is Deleted Successfully!');
        redirect(base_url('ManageAssets/ViewsTempAssets'));
      }else{
        $this->session->set_flashdata('msg', ' Deletion Error !');
        redirect(base_url('ManageAssets/ViewsTempAssets'));
      }
    }

    Function Edit_Temp_Asset($id){
      $data['id'] = $id;
      $data['asset_type'] = $this->Master_Model->Get_Asset_Type();
      $data['depts'] = $this->Master_Model->Get_Dep();
      $data['plants'] = $this->Master_Model->Get_Plant();
      $data['status'] = $this->Master_Model->Get_Status();
      $data['locations'] = $this->Master_Model->Get_Location();
      $data['AssetClass'] = $this->Master_Model->Get_AssetClass();
      $data['costcenter'] = $this->Master_Model->Get_CostCenter();
      $data['assetdata'] = $this->Asset_Model->Get_Temp_Assets_by_id($id);
      if (isset($_POST['submit'])) {
      
      $this->form_validation->set_rules('ta_gid',' Tag Id','trim|required|is_unique[temp_assets.tag_id]');
      $this->form_validation->set_rules('assetstatus',' Asset Status','trim|required');
      $this->form_validation->set_rules('asset_desc',' Asset Description','trim|required');
      $this->form_validation->set_rules('model',' Model','trim');
      $this->form_validation->set_rules('device_sl_no',' Device Sl No','trim');
      $this->form_validation->set_rules('make_oem',' Make/Oem','trim|required');
      $this->form_validation->set_rules('sbu',' S B U','trim');
      $this->form_validation->set_rules('capitilazetion_on',' Capitalized On','trim|required');
      $this->form_validation->set_rules('plant',' Plant','trim|required');
      $this->form_validation->set_rules('department',' Department','trim');
      $this->form_validation->set_rules('location',' Location','trim|required');
      $this->form_validation->set_rules('asset_user',' Asset User','trim');
      $this->form_validation->set_rules('cost_center',' Cost Center','trim|required');
      $this->form_validation->set_rules('po_no',' PO No','trim');
      $this->form_validation->set_rules('vendor',' Vendor','trim');
      $this->form_validation->set_rules('quantity',' It Asset Code','trim');
      $this->form_validation->set_rules('purchase_date',' Purchase Date','trim');
                           
            if ($this->form_validation->run()== TRUE) {
                $userdata = array(
                  'tag_id' => $_POST['ta_gid'],
                  'asset_status' => $_POST['assetstatus'],
                  'asset_user' => $_POST['asset_user'],
                  'sbu' => $_POST['sbu'],
                  'department' => $_POST['department'],
                  'plant' => $_POST['plant'], 
                  'make_oem' => $_POST['make_oem'],
                  'model' => $_POST['model'],
                  'device_sl_no' => $_POST['device_sl_no'],
                  'location' => $_POST['location'],
                  'vendor' => $_POST['vendor'],
                  'quantity' => $_POST['quantity'],
                  'cost_center' => $_POST['cost_center'],
                  'po_no' => $_POST['po_no'],
                  'description' => $_POST['asset_desc'],
                  'purchase_date' => $_POST['purchase_date'],
                  'capitalized_on' => $_POST['capitilazetion_on']
                  );
                if($this->Asset_Model->Update_temp_asset($userdata,$id) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Added Successfully!');
                    redirect(base_url('ManageAssets/ViewsTempAssets'));
                }else{
                    $this->session->set_flashdata('msg', ' Insertion Error !');
                    redirect(base_url('ManageAssets/ViewsTempAssets'));
                }
            }else{
              $this->template->load('template', 'Admin/Manage_Assets/Edit_Temp_Asset',$data);
            }
      }else{
      $this->template->load('template', 'Admin/Manage_Assets/Edit_Temp_Asset',$data);
      }
      
    }


    Function TempTransferAssets(){
      
      $data['Get_TemptransferAssets'] = $this->Asset_Model->Get_TemptransferAssets();
      $this->template->load('template', 'Admin/Manage_Assets/TempTransferAssets',$data);
    }  

    Function Search_TempAsset(){
      if (isset($_POST['submit'])) {
        $finance = $_POST['financeid'];
        $itcode = $_POST['itasset'];
        $data['finance'] = $finance;
        $data['itcode'] = $itcode; 
        $data['assetdata'] = $this->Asset_Model->GetTempAssetsMapp($finance,$itcode);
        $data['Finance_List'] = $this->Asset_Model->Finance_List();
        $data['ItAssetCode_List'] = $this->Asset_Model->Asset_Model->ItAssetCode_List();
        $this->template->load('template', 'Admin/Manage_Assets/TempTransferAssets',$data);
      }else{
      $data['Finance_List'] = $this->Asset_Model->Finance_List();
      $data['ItAssetCode_List'] = $this->Asset_Model->ItAssetCode_List();
      $this->template->load('template', 'Admin/Manage_Assets/TempTransferAssets',$data);
      }
    }

    function AddTidTempasset($id){
      $data['id'] =$id;
      if (isset($_POST['submit'])) {
        $this->form_validation->set_rules('tagid',' Tag Id','trim|required|is_unique[temp_assets.tag_id]|is_unique[mst_assets.tag_id]');
        $this->form_validation->set_rules('desc',' Description','trim|required');
                      
            if ($this->form_validation->run()== TRUE) {
                $userdata = array(
                            'tag_id' => $_POST['tagid'],
                            'description' => $_POST['desc'],
                            'updated_at' => date('Y-m-d h:m:s'),
                            'updated_by' => $_SESSION['email'],
                            'updation_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Asset_Model->Update_temp_asset($userdata,$id) == TRUE){
                    // Transfer data temp to trans
                  $ids = $id;
                  $this->API_Model->PostData_temp_to_trans($ids);
                  $this->session->set_flashdata('msg', ' Tag Mapped Successfully!');
                  redirect(base_url('Assets/Search_TempAsset'));
                }else{
                    $this->session->set_flashdata('msg', ' Insertion Error !');
                    redirect(base_url('Assets/AddTidTempasset/'.$id));
                }

            }else{
              $data['assetdata'] = $this->Asset_Model->Get_Temp_Assets_by_id($id); 
              $this->template->load('template', 'Admin/Manage_Assets/AddTagTo_TempAsset',$data);
            }
      }else{
      $data['assetdata'] = $this->Asset_Model->Get_Temp_Assets_by_id($id); 
      $this->template->load('template', 'Admin/Manage_Assets/AddTagTo_TempAsset',$data);
    }
    }


    /* Asset Transfer List */

    function TransferAssetList(){
      $loc = $_SESSION['plant'];
      $id = $_SESSION['user_type'];
      $data['list'] = $this->Asset_Model->Get_temp_transferassetList($loc,$id); 
      $this->template->load('template', 'Admin/Manage_Assets/Asset_Transfer_able_list',$data);
    }

    function TransferAssetNow($id){
      if($this->Asset_Model->TransferAssetNow($id) == TRUE){
      $this->session->set_flashdata('msg', ' Asset Transfer Successfully!');
      redirect(base_url('Assets/TransferAssetList'));
      }else{
        $this->session->set_flashdata('faliour', ' Id Not Match !');
        redirect(base_url('Assets/TransferAssetList'));
      }
    }

    function Deletetransfermanufest($id){
      if($this->Asset_Model->Deletetransfermanufest($id) == TRUE){
      $this->session->set_flashdata('msg', ' Asset Delete Successfully!');
      redirect(base_url('Assets/TransferAssetList'));
      }else{
        $this->session->set_flashdata('faliour', ' Id Not Match !');
        redirect(base_url('Assets/TransferAssetList'));
      }
    }

    /* Delete Mass temp data */

    public function deleteSelectedTemp(){
        $ids = $this->input->post('ids');
        $this->db->where_in('id', explode(",", $ids));
        $this->db->delete('temp_assets');
        echo json_encode(['success'=>"Item Deleted successfully."]);
      }
//Bulk Upload Registration
       /* Function Bulk_Upload_reg(){
        $this->template->load('template', 'Admin/Manage_Assets/Bulk_Upload_reg');
    }


  function Bulk_Uploadregisteration(){
      $ip = $_SERVER['REMOTE_ADDR'];
      $by = $_SESSION['email'];
      ini_set('max_execution_time', 0); 
      ini_set('memory_limit', '-1');
      if (isset($_POST['submit'])) {
        $file = $_FILES['bulk_reg']['tmp_name'];
        $type = explode(".",$_FILES['bulk_reg']['name']);
        if(strtolower(end($type)) == 'csv'){
        $handle = fopen($file, "r");
              $c = 1;//
              while(($filesop = fgetcsv($handle, 10000, ",")) !== false)
              {
                $tag_id = $filesop[0];
                $finance_asset_code = $filesop[1];
                $Asset_type = $filesop[2];
                $asset_class_id = $filesop[3];
                $assetsubclass = $filesop[4];
                $sbu = $filesop[5];
                $plant = $filesop[6];
                $dept = $filesop[7];
                $asset_user = $filesop[8];
                $captelization_on =date("Y-m-d", strtotime($filesop[9]));
                $cost_center = $filesop[10];
                $desc = $filesop[11];
                $make_oem = $filesop[12];
                $model = $filesop[13];
                $deviceslno = $filesop[14];
                $source_loc = $filesop[15];
                $vender = $filesop[16];
                $quantity = $filesop[17];
                $pono = $filesop[18];
                $purchase_date = date("Y-m-d", strtotime($filesop[19]));
                $itassetcode = $filesop[20];
                $statusid = $filesop[21];
                  if($c<>1){
                 // if (empty($this->Asset_Model->Findtagunique($tag_id))) {
                    $values[] = "('$tag_id','$finance_asset_code','$Asset_type','$asset_class_id','$assetsubclass','$sbu','$plant','$dept','$asset_user','$captelization_on','$cost_center','$desc','$make_oem','$model','$deviceslno','$source_loc','$vender','$quantity','$pono','$purchase_date','$itassetcode','$statusid','$by','$ip')";
                //  }else{
                    // $this->session->set_flashdata('faliour',' Tag "'.$tag_id.'" already Uploaded!');
                  //  redirect('index.php/Assets/Bulk_Upload_reg');
                 // }
                  
                  
                  }

                  $c = $c + 1;

                  
              }
              if (!empty($values)) {
                try{
                    $formdata =  implode(',',$values);
                    $quary = "INSERT INTO `mst_assets` (`tag_id`,`finance_asset_id`,`asset_type`, `asset_class_1`,`asset_sub_class`,`sbu`,`plant`,`department`,`asset_user`,`capitalized_on`,`cost_center`,`description`,`make_oem`,`model`,`device_sl_no`,`location`,`vendor`,`quantity`,`po_no`,`purchase_date`,`it_asset_code`,`asset_status`,`created_by`,`creation_ip`) VALUES $formdata;";
                    if ($this->Asset_Model->Ass_Bulk_date($quary) == TRUE) {
                      $this->session->set_flashdata('msg',' Successfully Uploded Asset Data!');
                      redirect('index.php/Assets/Bulk_Upload_reg');
                     }else{
                      $this->session->set_flashdata('faliour',' Insertion Error !');
                    redirect('index.php/Assets/Bulk_Upload_reg');
                     }
                 }catch (Exception $e) {
                     echo $e;
                  }
                  }
              }else{
                $this->session->set_flashdata('failure',' File format is not match. Only .CSV format allowed. you try to upload :- '.strtolower(end($type)) ." file that is wrong format !");
                  redirect('index.php/Assets/Bulk_Upload_reg');
              }

              
      }else{
      redirect('index.php/Assets/Bulk_Upload_reg');
      }
    }
*/

      Function Bulk_Upload_reg(){
        $this->template->load('template', 'Admin/Manage_Assets/Bulk_Upload_reg');
    }

           
    
    /*  Master  Bulk Upload reg */
    function Bulk_Uploadregisteration(){
      $ip = $_SERVER['REMOTE_ADDR'];
      $by = $_SESSION['email'];
      ini_set('max_execution_time', 0); 
      ini_set('memory_limit', '-1');
      if (isset($_POST['submit'])) {
        // Allowed mime types
        $csvMimes = array('text/x-comma-separated-values', 'text/comma-separated-values', 'application/octet-stream', 'application/vnd.ms-excel', 'application/x-csv', 'text/x-csv', 'text/csv', 'application/csv', 'application/excel', 'application/vnd.msexcel', 'text/plain');
        // Validate whether selected file is a CSV file
        if(!empty($_FILES['bulk_reg']['name']) && in_array($_FILES['bulk_reg']['type'], $csvMimes)){
        // If the file is uploaded
          if(is_uploaded_file($_FILES['bulk_reg']['tmp_name'])){
          // Open uploaded CSV file with read-only mode
            $csvFile = fopen($_FILES['bulk_reg']['tmp_name'], 'r');
            
            // Skip the first line
            fgetcsv($csvFile);
            $flag = 0;
            // check if data is already present behalf of tyre sl no 
            while(($line = fgetcsv($csvFile)) !== FALSE){
              // Get row data 
              $tag_id = trim($line[0]);
              $finance_asset_id = $line[1];
              $asset_type = $line[2];
              $asset_class_id = $line[3];
              $asset_sub_class = $line[4];
              $sbu = $line[5];
              $plant = $line[6];
              $department = $line[7];
              $asset_user = $line[8];
              $capitalized_on =date("Y-m-d", strtotime($line[9]));
              $cost_center = $line[10];
              $description = $line[11];
              $make_oem = $line[12];
              $model = $line[13];
              $device_sl_no = $line[14];
              $location = $line[15];
              $vendor = $line[16];
              $quantity = $line[17];
              $po_no = $line[18];
              $purchase_date = date("Y-m-d", strtotime($line[19]));
              $it_asset_code = $line[20];
              $asset_status = $line[21];
              $Tag_data = $this->Asset_Model->Findtagunique($tag_id);
              
              if (!empty($Tag_data->id) ){
                //echo "Battery Sl No ".$tag_id." Already Exist";  
                $flag = 1;
                $this->session->set_flashdata('faliour',' Tag Id '.$tag_id.'Already Uploaded !');
                redirect('Assets/Bulk_Upload_reg');
              }else{
                $insert[] = array(
                  "tag_id" => $tag_id,
                  "finance_asset_id" => $finance_asset_id,
                  "asset_type"=> $asset_type,
                  "asset_class_1" => $asset_class_id,
                  "asset_sub_class" => $asset_sub_class,
                  "sbu"=> $sbu,
                  "plant" => $plant,
                  "department" => $department,
                  "asset_user"=> $asset_user,
                  "capitalized_on" => $capitalized_on,
                  "cost_center" => $cost_center,
                  "description"=> $description,
                  "make_oem" => $make_oem,
                  "model" => $model,
                  "device_sl_no"=> $device_sl_no,
                  "location"=> $location,
                  "vendor"=>$vendor,
                  "quantity"=>$quantity,
                  "po_no"=>$po_no,
                  "purchase_date" => $purchase_date,
                  "it_asset_code" => $it_asset_code,
                  "asset_status" =>$asset_status,
                  "created_by" => $by,
                  "creation_ip" => $ip,
                 );
                      
                         
              }
            }
            try{
            if ((!empty($insert)) && ($this->db->insert_batch('mst_assets',$insert))) {
              $this->session->set_flashdata('msg',' Successfully Uploded Bulk Data !');
              redirect('Assets/Bulk_Upload_reg');
            }else{
              $this->session->set_flashdata('faliour',' Insertion Error !');
              redirect('Assets/Bulk_Upload_reg');
            }
            }catch (Exception $e) {
              echo $e;
            }
            fclose($csvFile); // close the file 
            
          }else{
            $this->session->set_flashdata('faliour',' No File Found !');
            redirect('Assets/Bulk_Upload_reg');
          }
        }else{
         // file formate is wrong
          $this->session->set_flashdata('faliour',' No File Found or no match file format.');
            redirect('Assets/Bulk_Upload_reg');
        }
        // end submission
      }else{
        redirect('Assets/Bulk_Upload_reg');
      }
    }
}
?>
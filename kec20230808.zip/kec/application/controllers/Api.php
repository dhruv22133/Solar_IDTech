<?php 

class API extends CI_Controller
{
	public function __construct(){
			parent::__construct();
			$this->load->model('API_Model', 'API_Model');
		}

	function Login(){
		if(!empty($_POST['username']) && !empty($_POST['password'])){
		$username = $_POST['username'];
		$password = md5($_POST['password']);
		}

		if (!empty($username) && !empty($password)) {
			$result = $this->API_Model->Match_Password($username,$password);
			if (!empty($result)) {
				print_r(json_encode(array("data"=>$result)));
				//print_r(json_encode($result,JSON_PRETTY_PRINT));
			}else{
				echo json_encode(array("data"=>"No Match User Details !"));
				//echo json_encode("No Match User Details");
			}
		}else{
			echo json_encode(array("data"=>"Enter username and password !"));
			//echo json_encode("Enter username and password");
		}
		
	}

	function Asset_Type_Master(){
		if (!empty($result = $this->API_Model->Get_Asset_Type())) {
		print_r(json_encode(array("data"=>$result)));
		}else{
		echo json_encode(array("data"=>"No Data Found !"));
		}
	}

	function Plant_Master(){
	//$result = $this->API_Model->Get_Plant();
	if (!empty($result = $this->API_Model->Get_Plant())) {
		print_r(json_encode(array("data"=>$result)));
		//print_r(json_encode($result,JSON_PRETTY_PRINT));
	}else{
		echo json_encode(array("data"=>"No Data Found !"));
		//echo json_encode("No Match User Details");
	}
		
	}


	function Dept_Master(){
	//$result = $this->API_Model->Get_Plant();
	if (!empty($result = $this->API_Model->Get_Dept())) {
		print_r(json_encode(array("data"=>$result)));
		//print_r(json_encode($result,JSON_PRETTY_PRINT));
	}else{
		echo json_encode(array("data"=>"No Data Found !"));
		//echo json_encode("No Match User Details");
	}
		
	}


	function Get_Assets_Data(){
		if (!empty($assettype = $_POST['department']) && !empty($plant = $_POST['plant'])) {
			if (!empty($result = $this->API_Model->Get_Assets($assettype,$plant))) {
				print_r(json_encode(array("msg"=>"Found","data"=>$result)));
				//print_r(json_encode($result,JSON_PRETTY_PRINT));
			}else{
				//echo json_encode(array("data"=>"No Data Found !"));
				print_r(json_encode(array("msg"=>" Not Found","data"=>$result)));
				//echo json_encode(array("msg"=>"No Data Found !"));
				//echo json_encode("No Match User Details");
			}
		}else{
			print_r(json_encode(array("data"=>$result)));
			echo json_encode(array("msg"=>" Not Found !"));
		}
	}


	function Post_Inventry_Data(){
		header('Content-Type: application/json');
		$jeson = file_get_contents('php://input');
		$data = json_decode($jeson,true);
		/*$jeson = json_decode(file_get_contents('php://input'), true);
		$data =  json_encode($jeson);*/
		//echo $data;
		$inv_id = "INV".date('Ymdhms').rand(00000,10000);
		$blogtags = array();
		foreach ($data['scan_data'] as $row) {
			$id = $row['id'];
			$tagid = $row['tag_id'];
			$asset_pr_code =  $row['asset_primary_code'];
			$scan_status = $row['scan_status'];
			$scan_by = $data['user_name'];
			$scan_time = $data['scan_date_time'];
			$values[] = "('$inv_id','$tagid','$asset_pr_code','$scan_status','$scan_by','$scan_time')";
			$update_ids[] = "$id";
			$scanstatus[] = "$scan_status";

			$blogtags[] = array(       
			    'id'=>$id,//this is current blog id       
			    'scan_status'=>$scan_status, 
			    'inventry_id'=>$inv_id, 
			    'scan_by'=>$scan_by, 
			    'scan_at'=>$scan_time,    
			    );
		}
		/*if($this->db->update_batch('mst_assets', $blogtags,'id')){
			echo "yes";
		}else{
			echo "oh no";
		}*/
		if (!empty($values)) {
			try{
				$formdata =  implode(',',$values);
				$quary = "INSERT INTO `inventry_log` (`inventry_id`,`tag_id`, `asset_primary_code`,`scan_status`,`scan_by`,`scan_time`) VALUES $formdata;";
				$inv_master = "INSERT INTO mst_inventry(inventry_id,created_by,inventary_date)VALUES('".$inv_id."','".$data['user_name']."','".$data['scan_date_time']."');";
				if ($this->API_Model->Add_Inventry_Log($quary) == TRUE && $this->db->update_batch('mst_assets', $blogtags,'id') && $this->API_Model->Add_Inventry_master($inv_master) == TRUE) {
					echo json_encode(array("data"=>" Sucess!"));
                   }else{
                   	echo json_encode(array("data"=>" Insertion Error !"));
                   }
               }catch (Exception $e) {
               	echo $e;
               }
           }else{
           	echo json_encode(array("data"=>" no input found !"));
           }
    	}


    	function Scan_Data(){
    		if (!empty($tag_is = $_GET['tagid'])) {
			if (!empty($result = $this->API_Model->Get_Identify_Data($tag_is))) {
				print_r(json_encode(array("msg"=>"Found","data"=>$result)));
				//print_r(json_encode($result,JSON_PRETTY_PRINT));
			}else{
				//echo json_encode(array("data"=>"No Data Found !"));
				print_r(json_encode(array("msg"=>" Not Found","data"=>$result)));
				//echo json_encode(array("msg"=>"No Data Found !"));
				//echo json_encode("No Match User Details");
			}
		}else{
			//print_r(json_encode(array("data"=>$result)));
			echo json_encode(array("msg"=>" No Input Found !"));
			}
    	}



    	function Get_Tagdata(){
    		if (!empty($tid = $_GET['tagid'])) {
			if (!empty($result = $this->API_Model->Get_Tagdata($tid))) {
				print_r(json_encode(array("msg"=>"Found","data"=>$result)));
				//print_r(json_encode($result,JSON_PRETTY_PRINT));
			}else{
				//echo json_encode(array("data"=>"No Data Found !"));
				print_r(json_encode(array("msg"=>" Not Found","data"=>$result)));
				//echo json_encode(array("msg"=>"No Data Found !"));
				//echo json_encode("No Match User Details");
			}
		}else{
			//print_r(json_encode(array("data"=>$result)));
			echo json_encode(array("msg"=>" No Input Found !"));
			}
    	}

    	function Post_Temp_TransferData(){
    		header('Content-Type: application/json');
			$jeson = file_get_contents('php://input');
			$data = json_decode($jeson,true);
			if (!empty($data['id']) && empty($this->API_Model->Check_transfer_log($data['tagid'],$data['sourceplant']))) {
				$logdata = array(
                  'tagid' => $data['tagid'],
                  'asset_id' => $data['id'],
                  'finance_asset_id' => $data['financeid'],
                  'it_assetcode' => $data['itassetcode'],
                  'source_plant' => $data['sourceplant'],
                  'source_dept' => $data['sourcedept'], 
                  'dest_plant' => $data['destinationplant'],
                  'desc_dept' => $data['descdept'],
                  'created_by' => $data['transferby']
                  );
                if($this->API_Model->Add_TransferTemp($logdata) == TRUE){
					echo json_encode(array("msg"=>"Done"));
                }else{
                	echo json_encode(array("msg"=>"Insertion Error !"));
                }
			}else{
				echo json_encode(array("msg"=>"Duplicate Entry !"));
			}
    	}

    	function Get_Temp_Tagdata(){
    		if (!empty($plant = trim($_GET['plant']))) {
			if (!empty($result = $this->API_Model->Get_Temp_Tagdata($plant))) {
				print_r(json_encode(array("msg"=>"Found","data"=>$result)));
				//print_r(json_encode($result,JSON_PRETTY_PRINT));
			}else{
				//echo json_encode(array("data"=>"No Data Found !"));
				print_r(json_encode(array("msg"=>" Not Found","data"=>$result)));
				//echo json_encode(array("msg"=>"No Data Found !"));
				//echo json_encode("No Match User Details");
			}
		}else{
			//print_r(json_encode(array("data"=>$result)));
			echo json_encode(array("msg"=>" No Input Found !"));
			}
    	}

    	function Send_Asset_Temp_to_trans(){
    		header('Content-Type: application/json');
			$jeson = file_get_contents('php://input');
			$data = json_decode($jeson,true);
			
			if (!empty($data['updatedby'])) {
				$blogtags = array();
				foreach ($data['datas'] as $row) {
					if(empty($row['tagid'])){
						$row['tagid'] = "0";
					}
					$blogtags[] = array(
					'id'=>$row['id'],     
				    'tag_id'=>$row['tagid'],
				    'created_by'=> $data['updatedby']   
				    ); 
				    $id[] = $row['id'];
				}
				$ids =  implode(',',$id);
				if($this->db->update_batch('temp_assets', $blogtags,'id') && $this->API_Model->PostData_temp_to_trans($ids)){
					echo json_encode(array("msg"=>"Done !"));
				}else{
					echo json_encode(array("msg"=>"Ids Not Found !"));
				}
				
			}else{
				echo json_encode(array("msg"=>" No Input Found !"));
			}

    	}

    function Get_Approved_Asset(){
    	if ( (!empty($tagid = trim($_POST['tagid']))) && (!empty($readerid = trim($_POST['readerid']))) ) {
			if (!empty($result = $this->API_Model->Get_approve_transfer_asset($tagid)) ) {
				print_r(json_encode(array("msg"=>"Found","data"=>$result)));
				//print_r(json_encode($result,JSON_PRETTY_PRINT));
			}else{										
				print_r(json_encode(array("msg"=>" Not Found","data"=>$result)));
			}
			$outlog = array(
				'tag_id'=>$_POST['tagid'],     
				'reader_id'=>$_POST['readerid'],
				'action'=> "OUT");
			$this->db->insert('out_gate_log', $outlog);
		}else{
			//print_r(json_encode(array("data"=>$result)));
			echo json_encode(array("msg"=>" No Input Found tagid and readerid !"));
			}
    }

}

?>
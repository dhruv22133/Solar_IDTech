<?php 



class Report extends CI_Controller

{

	public function __construct(){

        parent::__construct();
        $this->load->model('Report_Model', 'Report_Model');
        $this->load->model('Master_Model', 'Master_Model');
        $this->isLogin = $this->session->userdata('user_logged');
        if(!$this->isLogin){
        redirect(base_url('index.php/Auth/Logout'));
        }

    }



	function Asset_Wise(){

		$data['asset_type'] = $this->Master_Model->Get_Asset_Type();

		$data['depts'] = $this->Master_Model->Get_Dep();

		$data['plants'] = $this->Master_Model->Get_Plant();

		$data['status'] = $this->Master_Model->Get_Status();

		$data['locations'] = $this->Master_Model->Get_Location();

		$data['AssetClass'] = $this->Master_Model->Get_AssetClass();

		$data['costcenter'] = $this->Master_Model->Get_CostCenter();

		if (isset($_POST['submit'])){

			$tid = trim($_POST['tagid']);

			$itasset_code = trim($_POST['itasset_code']);

			$financeid = trim($_POST['financeid']);

			$Assettype = trim($_POST['Assettype']);

			$Assetclass = trim($_POST['Assetclass']);

			$department = trim($_POST['department']);

			$plant = trim($_POST['plant']);

			$location = trim($_POST['location']);

			$cost_center = trim($_POST['cost_center']);

			$asset_status = trim($_POST['asset_status']);

			$frome = trim(date("Y-m-d", strtotime($_POST['frome'])));

			$todate = trim(date("Y-m-d", strtotime($_POST['todate'])));

			$data['Assettype'] = $Assettype;

			$data['Assetclass'] = $Assetclass;

			$data['department'] = $department;

			$data['plantaa'] = $_POST['plant'];

			$data['location'] = $location;

			$data['cost_center'] = $cost_center;

			$data['asset_status'] = $asset_status;
			$loc = $_SESSION['plant'];
			$roleid = $_SESSION['user_type'];
			$data['assetdata'] = $this->Report_Model->Get_Asset_Wise_data_search($tid,$itasset_code,$financeid,$Assettype,$Assetclass,$department,$plant,$location,$cost_center,$asset_status,$frome,$todate,$loc,$roleid);

			$this->template->load('template', 'Admin/Reports/Asset_Wise_Report',$data);

		}else{
		$loc = $_SESSION['plant'];
		$roleid = $_SESSION['user_type'];
		$data['assetdata'] = $this->Report_Model->Get_Asset_Wise_data($loc,$roleid);
		$this->template->load('template', 'Admin/Reports/Asset_Wise_Report',$data);

		}

	}
	
	
	function Detail_Inv($id){
$data['Inventry'] = $this->Report_Model->Detailed_inv_session($id);
$this->template->load('template', 'Admin/Reports/Detailed_Inventory',$data);
}

	function Asset_History(){

		$this->load->view('admin/Report/Asset_History');

	}

	function Department_Wise(){

		$this->load->view('admin/Report/Department');

	}

	function Physical_Inventry(){
		$loc = $_SESSION['plant'];
		$roleid = $_SESSION['user_type'];
		if (isset($_POST['submit'])) {

			$from = trim(date("Y-m-d", strtotime($_POST['from'])));

			$to = trim(date("Y-m-d", strtotime($_POST['todate'])));

			$data['Inventry'] =$this->Report_Model->Inventry_Search($from,$to,$loc,$roleid);

			$this->template->load('template', 'Admin/Reports/Physical_inventry_report',$data);

		}else{

		$data['Inventry'] = $this->Report_Model->Inventry($loc,$roleid);

		$this->template->load('template', 'Admin/Reports/Physical_inventry_report',$data);

		}

	}



	function Asset_Transfer(){
		$roleid = $_SESSION['user_type'];
		if (isset($_POST['submit'])) {

			$from = trim(date("Y-m-d", strtotime($_POST['from'])));

			$to = trim(date("Y-m-d", strtotime($_POST['todate'])));
			$loc = $_SESSION['plant'];
			$data['assetdata'] = $this->Report_Model->Get_Asset_Transfer_search($from,$to,$loc,$roleid);

			$this->template->load('template', 'Admin/Reports/Asset_Transfer',$data);

		}else{
		$loc = $_SESSION['plant'];
		$data['assetdata'] = $this->Report_Model->Get_Asset_Transfer($loc,$roleid);
		$this->template->load('template', 'Admin/Reports/Asset_Transfer',$data);
		}

	}

	function DeletedAssets(){
		$plant = $_SESSION['plant'];
		$roleid = $_SESSION['user_type'];
		$data['log'] = $this->Report_Model->Get_Deleted_assets($plant,$roleid);
		$this->template->load('template', 'Admin/Reports/Deleted_Assets',$data);
	}


function Mst_Inv(){
		$loc = $_SESSION['plant'];
		$roleid = $_SESSION['user_type'];
		//print_r($this->Report_Model->Inventry($loc,$roleid));
		if (isset($_POST['submit'])) {

			$from = trim(date("Y-m-d", strtotime($_POST['from'])));

			$to = trim(date("Y-m-d", strtotime($_POST['todate'])));

			$data['Inventry'] =$this->Report_Model->Search_Mst_Inventry($from,$to,$loc,$roleid);

			$this->template->load('template', 'Admin/Reports/Mst_Inv',$data);

		}else{

		$data['Inventry'] = $this->Report_Model->Mst_Inventry($loc,$roleid);

		$this->template->load('template', 'Admin/Reports/Mst_Inv',$data);

		}

	}



	

}

?>
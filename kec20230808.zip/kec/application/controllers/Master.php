<?php 

class Master extends CI_Controller
{
	public function __construct(){
        parent::__construct();
        $this->isLogin = $this->session->userdata('user_logged');
        $this->load->model('Master_Model', 'Master_Model');
        $this->load->model('User_Model', 'User_Model');
        if(!$this->isLogin){
        redirect(base_url('index.php/Auth/Logout'));
        }
    }

/* Location Master */

	function Location_Master(){
        $id = $_SESSION['user_type'];
        $data['privilledge'] = $this->User_Model->Get_Privilledge_list($id);
		if (isset($_POST['submit'])) {
			$this->form_validation->set_rules('locname',' Location Name','trim|required|is_unique[mst_location.location_name]');
        	            
            if ($this->form_validation->run()== TRUE) {
                $userdata = array(
                            'location_name' => $_POST['locname'],
                            'status' => "1",
                            'created_by' => $_SESSION['email'],
                            'creation_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Master_Model->Add_Location($userdata) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Added Successfully!');
                    redirect(base_url('Master/Location'));
                }else{
                    $this->session->set_flashdata('msg', ' Insertion Error !');
                    redirect(base_url('Master/Location'));
                }

            }else{
            	$data['locations'] = $this->Master_Model->Get_Location();
                $this->template->load('template', 'Admin/Master/Location_Master',$data);
            }
		}else{
		$data['locations'] = $this->Master_Model->Get_Location();
        $this->template->load('template', 'Admin/Master/Location_Master',$data);
		}
	}

	Function Delete_Location($id){
		if($this->Master_Model->Delete_Location($id) == TRUE){
			$this->session->set_flashdata('msg', ' Record is Deleted Successfully!');
			redirect(base_url('Master/Location'));
		}else{
			$this->session->set_flashdata('msg', ' Deletion Error !');
			redirect(base_url('Master/Location'));
		}
	}

    function Edit_Location($id){
        $privedid = $_SESSION['user_type'];
        $data['privilledge'] = $this->User_Model->Get_Privilledge_list($privedid);
        if (isset($_POST['submit'])) {
            $this->form_validation->set_rules('locname',' Location Name','trim|required|is_unique[mst_location.location_name]');
            if ($this->form_validation->run()== TRUE) {
                $updatedata = array(
                            'location_name' => $_POST['locname'],
                            'status' => "1",
                            'updated_at'=>date('Y-m-d h:m:s'),
                            'updated_by' => $_SESSION['email'],
                            'updation_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Master_Model->Update_Location($updatedata,$id) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Updated Successfully!');
                    redirect(base_url('Master/Edit_Location/'.$id));
                }else{
                    $this->session->set_flashdata('msg', ' Updation Error !');
                    redirect(base_url('Master/Edit_Location/'.$id));
                }
            }else{
                $data['location_data'] = $this->Master_Model->Get_Location_byid($id);
                $data['id'] = $id;
                $this->template->load('template', 'Admin/Master/Edit/Edit_Location',$data);
            }
        }else{
        $data['location_data'] = $this->Master_Model->Get_Location_byid($id);
        $data['id'] = $id;
        $this->template->load('template', 'Admin/Master/Edit/Edit_Location',$data);
        }
    }


	/* Departmant Master */



	function Dep_Master(){
		$id = $_SESSION['user_type'];
        $data['privilledge'] = $this->User_Model->Get_Privilledge_list($id);
		if (isset($_POST['submit'])) {
			$this->form_validation->set_rules('deptname',' Departmant Name','trim|required|is_unique[mst_Dep.dep_name]');
        	            
            if ($this->form_validation->run()== TRUE) {
                $userdata = array(
                            'dep_name' => $_POST['deptname'],
                            'status' => "1",
                            'created_by' => $_SESSION['email'],
                            'creation_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Master_Model->Add_Dep($userdata) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Added Successfully!');
                    redirect(base_url('Master/Departmant'));
                }else{
                    $this->session->set_flashdata('msg', ' Insertion Error !');
                    redirect(base_url('Master/Departmant'));
                }

            }else{
            	$data['depts'] = $this->Master_Model->Get_Dep();
                $this->template->load('template', 'Admin/Master/DepartmantMaster',$data);
            }
		}else{
		$data['depts'] = $this->Master_Model->Get_Dep();
        $this->template->load('template', 'Admin/Master/DepartmantMaster',$data);
		}
	}

	Function Delete_Dept($id){
		if($this->Master_Model->Delete_Dept($id) == TRUE){
			$this->session->set_flashdata('msg', ' Record is Deleted Successfully!');
			redirect(base_url('Master/Departmant'));
		}else{
			$this->session->set_flashdata('msg', ' Deletion Error !');
			redirect(base_url('Master/Departmant'));
		}
	}

    function Edit_Dept($id){
        if (isset($_POST['submit'])) {
            $this->form_validation->set_rules('deptname',' Department Name','trim|required|is_unique[mst_Dep.dep_name]');
            if ($this->form_validation->run()== TRUE) {
                $updatedata = array(
                            'dep_name' => $_POST['deptname'],
                            'status' => "1",
                            'updated_at'=>date('Y-m-d h:m:s'),
                            'updated_by' => $_SESSION['email'],
                            'updation_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Master_Model->Update_Dept($updatedata,$id) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Updated Successfully!');
                    redirect(base_url('Master/Edit_Dept/'.$id));
                }else{
                    $this->session->set_flashdata('msg', ' Updation Error !');
                    redirect(base_url('Master/Edit_Dept/'.$id));
                }
            }else{
                $data['dept'] = $this->Master_Model->Get_Dep_by_id($id);
                $data['id'] = $id;
                $this->template->load('template', 'Admin/Master/Edit/Edit_Dept',$data);
            }
        }else{
        $data['dept'] = $this->Master_Model->Get_Dep_by_id($id);
        $data['id'] = $id;
        $this->template->load('template', 'Admin/Master/Edit/Edit_Dept',$data);
        }
    }



/*Asset Type Master */

	function Accet_Type_master(){
		$id = $_SESSION['user_type'];
        $data['privilledge'] = $this->User_Model->Get_Privilledge_list($id);
		if (isset($_POST['submit'])) {
			$this->form_validation->set_rules('asset_type_name',' Asset Type','trim|required|is_unique[mst_asset_type.type_name]');
        	            
            if ($this->form_validation->run()== TRUE) {
                $userdata = array(
                            'type_name' => $_POST['asset_type_name'],
                            'status' => "1",
                            'created_by' => $_SESSION['email'],
                            'creation_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Master_Model->Add_Asset_Type($userdata) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Added Successfully!');
                    redirect(base_url('Master/Asset_Type'));
                }else{
                    $this->session->set_flashdata('msg', ' Insertion Error !');
                    redirect(base_url('Master/Asset_Type'));
                }

            }else{
            	$data['asset_type'] = $this->Master_Model->Get_Asset_Type();
                $this->template->load('template', 'Admin/Master/AssetTypeMaster',$data);
            }
		}else{
		$data['asset_type'] = $this->Master_Model->Get_Asset_Type();
		//$this->load->view('admin/Master/Asset_Type_master',$data);
        $this->template->load('template', 'Admin/Master/AssetTypeMaster',$data);
		}
	}

	Function Delete_Asset_Type($id){
		if($this->Master_Model->Delete_Asset_Type($id) == TRUE){
			$this->session->set_flashdata('msg', ' Record is Deleted Successfully!');
			redirect(base_url('Master/Asset_Type'));
		}else{
			$this->session->set_flashdata('msg', ' Deletion Error !');
			redirect(base_url('Master/Asset_Type'));
		}
	}

    function Edit_Asset_Type($id){
        if (isset($_POST['submit'])) {
            $this->form_validation->set_rules('asset_type_name',' Asset type Name','trim|required|is_unique[mst_asset_type.type_name]');
            if ($this->form_validation->run()== TRUE) {
                $updatedata = array(
                            'type_name' => $_POST['asset_type_name'],
                            'status' => "1",
                            'updated_at'=>date('Y-m-d h:m:s'),
                            'updated_by' => $_SESSION['email'],
                            'updation_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Master_Model->Update_AssetType($updatedata,$id) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Updated Successfully!');
                    redirect(base_url('Master/Edit_Asset_Type/'.$id));
                }else{
                    $this->session->set_flashdata('msg', ' Updation Error !');
                    redirect(base_url('Master/Edit_Asset_Type/'.$id));
                }
            }else{
                $data['assettype'] = $this->Master_Model->Get_Asset_Type_by_id($id);
                $data['id'] = $id;
                $this->template->load('template', 'Admin/Master/Edit/Edit_AssetTypeMaster',$data);
            }
        }else{
        $data['assettype'] = $this->Master_Model->Get_Asset_Type_by_id($id);
        $data['id'] = $id;
        $this->template->load('template', 'Admin/Master/Edit/Edit_AssetTypeMaster',$data);
        }
    }


/*Plant Master */

	function Plant_Master(){
		$id = $_SESSION['user_type'];
        $data['privilledge'] = $this->User_Model->Get_Privilledge_list($id);
		if (isset($_POST['submit'])) {
			$this->form_validation->set_rules('plantname',' Plant Name','trim|required');
        	$this->form_validation->set_rules('plantemail',' Plant Email','trim|required|valid_email|is_unique[mst_plant.plant_email]');            
            if ($this->form_validation->run()== TRUE) {
                $userdata = array(
                            'plant_name' => $_POST['plantname'],
                            'plant_email' => $_POST['plantemail'],
                            'status' => "1",
                            'created_by' => $_SESSION['email'],
                            'creation_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Master_Model->Add_Plant($userdata) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Added Successfully!');
                    redirect(base_url('Master/Plant'));
                }else{
                    $this->session->set_flashdata('msg', ' Insertion Error !');
                    redirect(base_url('Master/Plant'));
                }

            }else{
            	$data['plants'] = $this->Master_Model->Get_Plant();
                $this->template->load('template', 'Admin/Master/PlantMaster',$data);
            }
		}else{
		$data['plants'] = $this->Master_Model->Get_Plant();
        $this->template->load('template', 'Admin/Master/PlantMaster',$data);
		}
	}

	Function Delete_Plant($id){
        if($this->Master_Model->Delete_Plant($id) == TRUE){
			$this->session->set_flashdata('msg', ' Record is Deleted Successfully!');
			redirect(base_url('Master/Plant'));
		}else{
			$this->session->set_flashdata('msg', ' Deletion Error !');
			redirect(base_url('Master/Plant'));
		}
	}

    function Edit_Plant($id){
        if (isset($_POST['submit'])) {
            $this->form_validation->set_rules('plantname',' Plant Name','trim|required|is_unique[mst_plant.plant_name]');
            $this->form_validation->set_rules('plantemail',' Plant Email','trim|required|is_unique[mst_plant.plant_name]');
            if ($this->form_validation->run()== TRUE) {
                $updatedata = array(
                            'plant_name' => $_POST['plantname'],
                            'plant_email'=>$_POST['plantemail'],
                            'status' => "1",
                            'updated_at'=>date('Y-m-d h:m:s'),
                            'updated_by' => $_SESSION['email'],
                            'updated_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Master_Model->Update_Plant($updatedata,$id) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Updated Successfully!');
                    redirect(base_url('Master/Edit_Plant/'.$id));
                }else{
                    $this->session->set_flashdata('msg', ' Updation Error !');
                    redirect(base_url('Master/Edit_Plant/'.$id));
                }
            }else{
                $data['plant'] = $this->Master_Model->Get_Plant_by_id($id);
                $data['id'] = $id;
                $this->template->load('template', 'Admin/Master/Edit/Edit_PlantMaster',$data);
            }
        }else{
        $data['plant'] = $this->Master_Model->Get_Plant_by_id($id);
        $data['id'] = $id;
        $this->template->load('template', 'Admin/Master/Edit/Edit_PlantMaster',$data);
        }
    }

/* Asset Status Master */

	function Asset_Status_master(){
		$id = $_SESSION['user_type'];
        $data['privilledge'] = $this->User_Model->Get_Privilledge_list($id);
		if (isset($_POST['submit'])) {
			$this->form_validation->set_rules('satus_name',' Status Name','trim|required|is_unique[mst_asset_status.status_name]');
        	            
            if ($this->form_validation->run()== TRUE) {
                $userdata = array(
                            'status_name' => $_POST['satus_name'],
                            'status' => "1",
                            'created_by' => $_SESSION['email'],
                            'creation_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Master_Model->Add_Status($userdata) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Added Successfully!');
                    redirect(base_url('Master/Asset_Status'));
                }else{
                    $this->session->set_flashdata('msg', ' Insertion Error !');
                    redirect(base_url('Master/Asset_Status'));
                }

            }else{
            	$data['status'] = $this->Master_Model->Get_Status();
                $this->template->load('template', 'Admin/Master/AssetStatusMaster',$data);
            }
		}else{
		$data['status'] = $this->Master_Model->Get_Status();
        $this->template->load('template', 'Admin/Master/AssetStatusMaster',$data);
		}
	}

	Function Delete_Status($id){
		if($this->Master_Model->Delete_Status($id) == TRUE){
			$this->session->set_flashdata('msg', ' Record is Deleted Successfully!');
			redirect(base_url('Master/Asset_Status'));
		}else{
			$this->session->set_flashdata('msg', ' Deletion Error !');
			redirect(base_url('Master/Asset_Status'));
		}
	}

    function Edit_AssetStatus($id){
        if (isset($_POST['submit'])) {
            $this->form_validation->set_rules('satus_name',' Asset Status Name','trim|required|is_unique[mst_asset_status.status_name]');
            if ($this->form_validation->run()== TRUE) {
                $updatedata = array(
                            'status_name' => $_POST['satus_name'],
                            'status' => "1",
                            'updated_at'=>date('Y-m-d h:m:s'),
                            'updated_by' => $_SESSION['email'],
                            'updation_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Master_Model->Update_AssetStatus($updatedata,$id) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Updated Successfully!');
                    redirect(base_url('Master/Edit_AssetStatus/'.$id));
                }else{
                    $this->session->set_flashdata('msg', ' Updation Error !');
                    redirect(base_url('Master/Edit_AssetStatus/'.$id));
                }
            }else{
                $data['status'] = $this->Master_Model->Get_Status_BYID($id);
                $data['id'] = $id;
                $this->template->load('template', 'Admin/Master/Edit/Edit_AssetStatusMaster',$data);
            }
        }else{
        $data['status'] = $this->Master_Model->Get_Status_BYID($id);
        $data['id'] = $id;
        $this->template->load('template', 'Admin/Master/Edit/Edit_AssetStatusMaster',$data);
        }
    }

	/* Asset Class Master */ 

	function Asset_Class_master(){
		$id = $_SESSION['user_type'];
        $data['privilledge'] = $this->User_Model->Get_Privilledge_list($id);
		if (isset($_POST['submit'])) {
			$this->form_validation->set_rules('class_code',' Asset Class Code','trim|required|is_unique[mst_asset_class.asset_class_code]');
			$this->form_validation->set_rules('class_name',' Asset Class Name','trim|required|is_unique[mst_asset_class.asset_class_name]');        	            
            if ($this->form_validation->run()== TRUE) {
                $userdata = array(
                            'asset_class_code' => $_POST['class_code'],
                            'asset_class_name' => $_POST['class_name'],
                            'status' => "1",
                            'created_by' => $_SESSION['email'],
                            'creation_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Master_Model->Add_AssetClass($userdata) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Added Successfully!');
                    redirect(base_url('Master/AssetClass'));
                }else{
                    $this->session->set_flashdata('msg', ' Insertion Error !');
                    redirect(base_url('Master/AssetClass'));
                }

            }else{
            	$data['assetclass'] = $this->Master_Model->Get_AssetClass();
                $this->template->load('template', 'Admin/Master/AssetClassMaster',$data);
            }
		}else{
		$data['assetclass'] = $this->Master_Model->Get_AssetClass();
        $this->template->load('template', 'Admin/Master/AssetClassMaster',$data);
		}
	}

	Function Delete_Asset_Class($id){
		if($this->Master_Model->Delete_AssetClass($id) == TRUE){
			$this->session->set_flashdata('msg', ' Record is Deleted Successfully!');
			redirect(base_url('Master/AssetClass'));
		}else{
			$this->session->set_flashdata('msg', ' Deletion Error !');
			redirect(base_url('Master/AssetClass'));
		}
	}

    function Edit_AssetClass($id){
        if (isset($_POST['submit'])) {
            $this->form_validation->set_rules('class_code',' Asset Class Code','trim|required|is_unique[mst_asset_class.asset_class_code]');
            $this->form_validation->set_rules('class_name',' Asset Class Name','trim|required|is_unique[mst_asset_class.asset_class_name]');
            if ($this->form_validation->run()== TRUE) {
                $updatedata = array(
                            'asset_class_code' => $_POST['class_code'],
                            'asset_class_name' => $_POST['class_name'],
                            'status' => "1",
                            'updated_at'=>date('Y-m-d h:m:s'),
                            'updated_by' => $_SESSION['email'],
                            'updation_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Master_Model->Update_AssetClass($updatedata,$id) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Updated Successfully!');
                    redirect(base_url('Master/Edit_AssetClass/'.$id));
                }else{
                    $this->session->set_flashdata('msg', ' Updation Error !');
                    redirect(base_url('Master/Edit_AssetClass/'.$id));
                }
            }else{
                $data['assetclass'] = $this->Master_Model->Get_AssetClass_by_id($id);
                $data['id'] = $id;
                $this->template->load('template', 'Admin/Master/Edit/Edit_AssetClassMaster',$data);
            }
        }else{
        $data['assetclass'] = $this->Master_Model->Get_AssetClass_by_id($id);
        $data['id'] = $id;
        $this->template->load('template', 'Admin/Master/Edit/Edit_AssetClassMaster',$data);
        }
    }

	/* Cost Center Master */

	function Asset_CostCenter(){
		$id = $_SESSION['user_type'];
        $data['privilledge'] = $this->User_Model->Get_Privilledge_list($id);
		if (isset($_POST['submit'])) {
			$this->form_validation->set_rules('CostCenter',' Cost Center Name','trim|required|is_unique[mst_cost_center.cost_center_name]');     	            
            if ($this->form_validation->run()== TRUE) {
                $userdata = array(
                            'cost_center_name' => $_POST['CostCenter'],
                            'status' => "1",
                            'created_by' => $_SESSION['email'],
                            'creation_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Master_Model->Add_CostCenter($userdata) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Added Successfully!');
                    redirect(base_url('Master/CostCenter'));
                }else{
                    $this->session->set_flashdata('msg', ' Insertion Error !');
                    redirect(base_url('Master/CostCenter'));
                }

            }else{
            	$data['CostCenter'] = $this->Master_Model->Get_CostCenter();
                $this->template->load('template', 'Admin/Master/CostCenterMaster',$data);
            }
		}else{
		$data['CostCenter'] = $this->Master_Model->Get_CostCenter();
        $this->template->load('template', 'Admin/Master/CostCenterMaster',$data);
		}
	}

	Function Delete_CostCenter($id){
		if($this->Master_Model->Delete_CostCenter($id) == TRUE){
			$this->session->set_flashdata('msg', ' Record is Deleted Successfully!');
			redirect(base_url('Master/CostCenter'));
		}else{
			$this->session->set_flashdata('msg', ' Deletion Error !');
			redirect(base_url('Master/CostCenter'));
		}
	}

    function Edit_AssetCostCenter($id){
        if (isset($_POST['submit'])) {
            $this->form_validation->set_rules('CostCenter',' Cost Center','trim|required|is_unique[mst_cost_center.cost_center_name]');
            if ($this->form_validation->run()== TRUE) {
                $updatedata = array(
                            'cost_center_name' => $_POST['CostCenter'],
                            'status' => "1",
                            'updated_at'=>date('Y-m-d h:m:s'),
                            'updated_by' => $_SESSION['email'],
                            'updation_ip' => getenv("REMOTE_ADDR")
                            );
                if($this->Master_Model->Update_CostCenter($updatedata,$id) == TRUE){
                    $this->session->set_flashdata('msg', ' Record is Updated Successfully!');
                    redirect(base_url('Master/Edit_AssetCostCenter/'.$id));
                }else{
                    $this->session->set_flashdata('msg', ' Updation Error !');
                    redirect(base_url('Master/Edit_AssetCostCenter/'.$id));
                }
            }else{
                $data['costcenter'] = $this->Master_Model->Get_CostCenterByiD($id);
                $data['id'] = $id;
                $this->template->load('template', 'Admin/Master/Edit/Edit_CostCenterMaster',$data);
            }
        }else{
        $data['costcenter'] = $this->Master_Model->Get_CostCenterByiD($id);
        $data['id'] = $id;
        $this->template->load('template', 'Admin/Master/Edit/Edit_CostCenterMaster',$data);
        }
    }
}

?>
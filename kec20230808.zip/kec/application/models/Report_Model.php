<?php 

class Report_Model extends CI_Model
{ 	
	function Get_Asset_Transfer($loc,$roleid){
		if($roleid =='1'){
			$query = $this->db->query("SELECT t1.id,t1.tagid,t1.asset_id,t1.source_loc,t1.source_plant,t1.destination_loc,t1.dest_plant,
		(SELECT location_name FROM mst_location WHERE mst_location.id = t1.destination_loc)AS desc_loc_name,
		(SELECT plant_name FROM mst_plant WHERE mst_plant.id = t1.dest_plant)AS desc_plant_name,
		(SELECT status_name FROM mst_asset_status WHERE t2.asset_status = mst_asset_status.id) AS status_name,
		(SELECT dep_name FROM mst_Dep WHERE t2.department = mst_Dep.id) AS deptname, 
		t1.created_by,t1.created_at,t2.it_asset_code,t2.finance_asset_id,t2.description,t2.asset_user
		FROM asset_transfer_log AS t1
		INNER JOIN mst_assets AS t2 ON t1.tagid = t2.tag_id
		WHERE status = '1'");
		return $query->result_array();
	}else{
	$query = $this->db->query("SELECT t1.id,t1.tagid,t1.asset_id,t1.source_loc,t1.source_plant,t1.destination_loc,t1.dest_plant,
		(SELECT location_name FROM mst_location WHERE mst_location.id = t1.destination_loc)AS desc_loc_name,
		(SELECT plant_name FROM mst_plant WHERE mst_plant.id = t1.dest_plant)AS desc_plant_name,
		(SELECT status_name FROM mst_asset_status WHERE t2.asset_status = mst_asset_status.id) AS status_name,
		(SELECT dep_name FROM mst_Dep WHERE t2.department = mst_Dep.id) AS deptname, 
		t1.created_by,t1.created_at,t2.it_asset_code,t2.finance_asset_id,t2.description,t2.asset_user
		FROM asset_transfer_log AS t1
		INNER JOIN mst_assets AS t2 ON t1.tagid = t2.tag_id
		WHERE status = '1' and t1.source_plant = '".$loc."' or t1.destination_loc = '".$loc."' ");
		return $query->result_array();
		}
	}

	function Get_Asset_Transfer_search($from,$to,$loc,$roleid ){
		if($roleid =='1'){
			$query = $this->db->query("SELECT t1.id,t1.tagid,t1.asset_id,t1.source_loc,t1.source_plant,t1.destination_loc,t1.dest_plant,
		(SELECT location_name FROM mst_location WHERE mst_location.id = t1.destination_loc)AS desc_loc_name,
		(SELECT plant_name FROM mst_plant WHERE mst_plant.id = t1.dest_plant)AS desc_plant_name,
		(SELECT status_name FROM mst_asset_status WHERE t2.asset_status = mst_asset_status.id) AS status_name,
		(SELECT dep_name FROM mst_Dep WHERE t2.department = mst_Dep.id) AS deptname, 
		t1.created_by,t1.created_at,t2.it_asset_code,t2.finance_asset_id,t2.description,t2.asset_user
		FROM asset_transfer_log AS t1
		INNER JOIN mst_assets AS t2 ON t1.tagid = t2.tag_id
		WHERE CAST(t1.created_at AS DATE) BETWEEN '".$from."' AND '".$to."' and status='1'");
		return $query->result_array();
	}else{
	$query = $this->db->query("SELECT t1.id,t1.tagid,t1.asset_id,t1.source_loc,t1.source_plant,t1.destination_loc,t1.dest_plant,
		(SELECT location_name FROM mst_location WHERE mst_location.id = t1.destination_loc)AS desc_loc_name,
		(SELECT plant_name FROM mst_plant WHERE mst_plant.id = t1.dest_plant)AS desc_plant_name,
		(SELECT status_name FROM mst_asset_status WHERE t2.asset_status = mst_asset_status.id) AS status_name,
		(SELECT dep_name FROM mst_Dep WHERE t2.department = mst_Dep.id) AS deptname, 
		t1.created_by,t1.created_at,t2.it_asset_code,t2.finance_asset_id,t2.description,t2.asset_user
		FROM asset_transfer_log AS t1
		INNER JOIN mst_assets AS t2 ON t1.tagid = t2.tag_id
		WHERE CAST(t1.created_at AS DATE) BETWEEN '".$from."' AND '".$to."' and status='1' and t1.dest_plant = '".$loc."' or t1.source_plant = '".$loc."' ");
		return $query->result_array();
	}
	}

	function Inventry($loc,$roleid){
		if($roleid =='1'){
			$query = $this->db->query("SELECT t1.id,t1.tag_id,t2.it_asset_code,t2.finance_asset_id,t2.description,t2.asset_user,t1.scan_status,t2.department,t1.scan_time,
		(SELECT status_name FROM mst_asset_status WHERE t2.asset_status = mst_asset_status.id) AS status_name, 
        (select mst_Dep.dep_name from mst_Dep where t2.department = mst_Dep.id) as depname
		FROM inventry_log AS t1
		left JOIN mst_assets AS t2 ON t1.tag_id = t2.tag_id
		");
		return $query->result_array();
		}else{
		$query = $this->db->query("SELECT t1.id,t1.tag_id,t2.it_asset_code,t2.finance_asset_id,t2.description,t2.asset_user,t1.scan_status,t2.department,t1.scan_time,
		(SELECT status_name FROM mst_asset_status WHERE t2.asset_status = mst_asset_status.id) AS status_name, 
        (select mst_Dep.dep_name from mst_Dep where t2.department = mst_Dep.id) as depname
		FROM inventry_log AS t1
		left JOIN mst_assets AS t2 ON t1.tag_id = t2.tag_id
		where t2.plant ='".$loc."'
		");
		return $query->result_array();
		}
	}

	function Inventry_Search($from,$to,$loc,$roleid){
		if($roleid =='1'){
			$query = $this->db->query("SELECT t1.id,t1.tag_id,t2.it_asset_code,t2.finance_asset_id,t2.description,t2.asset_user,t1.scan_status,t2.department,t2.department,t1.scan_time,
		(SELECT status_name FROM mst_asset_status WHERE t2.asset_status = mst_asset_status.id) AS status_name,
		(select mst_Dep.dep_name from mst_Dep where t2.department = mst_Dep.id) as depname 
		FROM inventry_log AS t1
		LEFT JOIN mst_assets AS t2 ON t1.tag_id = t2.tag_id
		WHERE CAST(t1.scan_time AS DATE) BETWEEN '".$from."' AND '".$to."'");
		return $query->result_array();
		}else{
		$query = $this->db->query("SELECT t1.id,t1.tag_id,t2.it_asset_code,t2.finance_asset_id,t2.description,t2.asset_user,t1.scan_status,t2.department,t2.department,t1.scan_time,
		(SELECT status_name FROM mst_asset_status WHERE t2.asset_status = mst_asset_status.id) AS status_name,
		(select mst_Dep.dep_name from mst_Dep where t2.department = mst_Dep.id) as depname 
		FROM inventry_log AS t1
		LEFT JOIN mst_assets AS t2 ON t1.tag_id = t2.tag_id
		WHERE CAST(t1.scan_time AS DATE) BETWEEN '".$from."' AND '".$to."' and t2.plant ='".$loc."'");
		return $query->result_array();
		}
	}

	function Get_Asset_Wise_data($loc,$roleid){
		if($roleid == '1'){
			$query = $this->db->query("SELECT t1.id,t1.tag_id,t1.asset_primary_code,t1.asset_type,t1.finance_asset_id,t1.sbu,t1.asset_class_1,t1.asset_class_2,t1.asset_sub_class,
		t1.department,t1.plant,make_oem,t1.model,t1.device_sl_no,t1.location,t1.vendor,t1.quantity,t1.it_asset_code,t1.cost_center,t1.po_no,t1.description,
		t1.asset_user,t1.asset_status,t1.purchase_date,t1.capitalized_on,t1.created_at,t1.created_by,
		mst_asset_type.type_name,mst_asset_class.asset_class_code,mst_asset_class.asset_class_name,
		mst_Dep.dep_name,mst_plant.plant_name,mst_location.location_name,mst_asset_status.status_name
		FROM mst_assets AS t1
		LEFT JOIN mst_asset_type ON t1.asset_type = mst_asset_type.id
		LEFT JOIN mst_asset_class ON t1.asset_class_1 = mst_asset_class.id
		LEFT JOIN mst_Dep ON t1.department = mst_Dep.id
		LEFT JOIN mst_plant ON t1.plant = mst_plant.id
		LEFT JOIN mst_location ON t1.location = mst_location.id
		LEFT JOIN mst_asset_status ON t1.asset_status = mst_asset_status.id
		WHERE t1.delete_atatus = '0'
		");
		return $query->result_array();
	}else{
		$query = $this->db->query("SELECT t1.id,t1.tag_id,t1.asset_primary_code,t1.asset_type,t1.finance_asset_id,t1.sbu,t1.asset_class_1,t1.asset_class_2,t1.asset_sub_class,
		t1.department,t1.plant,make_oem,t1.model,t1.device_sl_no,t1.location,t1.vendor,t1.quantity,t1.it_asset_code,t1.cost_center,t1.po_no,t1.description,
		t1.asset_user,t1.asset_status,t1.purchase_date,t1.capitalized_on,t1.created_at,t1.created_by,
		mst_asset_type.type_name,mst_asset_class.asset_class_code,mst_asset_class.asset_class_name,
		mst_Dep.dep_name,mst_plant.plant_name,mst_location.location_name,mst_asset_status.status_name
		FROM mst_assets AS t1
		LEFT JOIN mst_asset_type ON t1.asset_type = mst_asset_type.id
		LEFT JOIN mst_asset_class ON t1.asset_class_1 = mst_asset_class.id
		LEFT JOIN mst_Dep ON t1.department = mst_Dep.id
		LEFT JOIN mst_plant ON t1.plant = mst_plant.id
		LEFT JOIN mst_location ON t1.location = mst_location.id
		LEFT JOIN mst_asset_status ON t1.asset_status = mst_asset_status.id
		WHERE t1.plant = '".$loc."' AND delete_atatus = '0'
		");
		return $query->result_array();
	}
	}

	function Get_Asset_Wise_data_search($tid,$itasset_code,$financeid,$Assettype,$Assetclass,$department,$plant,$location,$cost_center,$asset_status,$frome,$todate,$loc,$roleid){
		if($roleid =='1'){
			$whereArr = array();
        
        if(!empty($tid)) $whereArr[] = "AND t1.tag_id LIKE '%".$tid."%'";
        if(!empty($itasset_code)) $whereArr[] = "AND t1.it_asset_code = '".$itasset_code."'";
        if(!empty($financeid)) $whereArr[] = "AND t1.finance_asset_id = '".$financeid."'";
        if(!empty($Assettype)) $whereArr[] = "AND t1.asset_type = '".$Assettype."'";

        if(!empty($Assetclass)) $whereArr[] = "AND t1.asset_class_1 = '".$Assetclass."'";
        if(!empty($department)) $whereArr[] = "AND t1.department = '".$department."'";
        if(!empty($plant)) $whereArr[] = "AND t1.plant = '".$plant."'";
        if(!empty($location)) $whereArr[] = "AND t1.location = '".$location."'";
        if(!empty($cost_center)) $whereArr[] = "AND t1.cost_center = '".$cost_center."'";
        if(!empty($asset_status)) $whereArr[] = "AND t1.asset_status = '".$asset_status."'";

        $whereStr = implode("  ", $whereArr);

		$query = $query = $this->db->query("SELECT t1.id,t1.tag_id,t1.asset_primary_code,t1.asset_type,t1.finance_asset_id,t1.sbu,t1.asset_class_1,t1.asset_class_2,t1.asset_sub_class,
		t1.department,t1.plant,make_oem,t1.model,t1.device_sl_no,t1.location,t1.vendor,t1.quantity,t1.it_asset_code,t1.cost_center,t1.po_no,t1.description,
		t1.asset_user,t1.asset_status,t1.purchase_date,t1.capitalized_on,t1.created_at,t1.created_by,
		mst_asset_type.type_name,mst_asset_class.asset_class_code,mst_asset_class.asset_class_name,
		mst_Dep.dep_name,mst_plant.plant_name,mst_location.location_name,mst_asset_status.status_name
		FROM mst_assets AS t1
		LEFT JOIN mst_asset_type ON t1.asset_type = mst_asset_type.id
		LEFT JOIN mst_asset_class ON t1.asset_class_1 = mst_asset_class.id
		LEFT JOIN mst_Dep ON t1.department = mst_Dep.id
		LEFT JOIN mst_plant ON t1.plant = mst_plant.id
		LEFT JOIN mst_location ON t1.location = mst_location.id
		LEFT JOIN mst_asset_status ON t1.asset_status = mst_asset_status.id
		WHERE delete_atatus = '0' AND CAST(t1.created_at AS DATE) BETWEEN '".$frome."' AND '".$todate."' $whereStr");
		return $query->result_array();
	}else{

		$whereArr = array();
        
        if(!empty($tid)) $whereArr[] = "AND t1.tag_id LIKE '%".$tid."%'";
        if(!empty($itasset_code)) $whereArr[] = "AND t1.it_asset_code = '".$itasset_code."'";
        if(!empty($financeid)) $whereArr[] = "AND t1.finance_asset_id = '".$financeid."'";
        if(!empty($Assettype)) $whereArr[] = "AND t1.asset_type = '".$Assettype."'";

        if(!empty($Assetclass)) $whereArr[] = "AND t1.asset_class_1 = '".$Assetclass."'";
        if(!empty($department)) $whereArr[] = "AND t1.department = '".$department."'";
        if(!empty($plant)) $whereArr[] = "AND t1.plant = '".$plant."'";
        if(!empty($location)) $whereArr[] = "AND t1.location = '".$location."'";
        if(!empty($cost_center)) $whereArr[] = "AND t1.cost_center = '".$cost_center."'";
        if(!empty($asset_status)) $whereArr[] = "AND t1.asset_status = '".$asset_status."'";

        $whereStr = implode("  ", $whereArr);

		$query = $query = $this->db->query("SELECT t1.id,t1.tag_id,t1.asset_primary_code,t1.asset_type,t1.finance_asset_id,t1.sbu,t1.asset_class_1,t1.asset_class_2,t1.asset_sub_class,
		t1.department,t1.plant,make_oem,t1.model,t1.device_sl_no,t1.location,t1.vendor,t1.quantity,t1.it_asset_code,t1.cost_center,t1.po_no,t1.description,
		t1.asset_user,t1.asset_status,t1.purchase_date,t1.capitalized_on,t1.created_at,t1.created_by,
		mst_asset_type.type_name,mst_asset_class.asset_class_code,mst_asset_class.asset_class_name,
		mst_Dep.dep_name,mst_plant.plant_name,mst_location.location_name,mst_asset_status.status_name
		FROM mst_assets AS t1
		LEFT JOIN mst_asset_type ON t1.asset_type = mst_asset_type.id
		LEFT JOIN mst_asset_class ON t1.asset_class_1 = mst_asset_class.id
		LEFT JOIN mst_Dep ON t1.department = mst_Dep.id
		LEFT JOIN mst_plant ON t1.plant = mst_plant.id
		LEFT JOIN mst_location ON t1.location = mst_location.id
		LEFT JOIN mst_asset_status ON t1.asset_status = mst_asset_status.id
		WHERE delete_atatus = '0' and t1.plant = '".$loc."' AND CAST(t1.created_at AS DATE) BETWEEN '".$frome."' AND '".$todate."' $whereStr");
		return $query->result_array();
		}
	}	

	function Get_Deleted_assets($plant,$roleid){
		if($roleid =='1'){
			$query = $this->db->query("SELECT t1.id,t1.tag_id,t1.finance_asset_id,t1.it_asset_code,t1.department,t1.plant,t1.asset_user,t2.deletion_by,t2.deletion_at,
			t3.plant_name,t4.dep_name
			FROM mst_assets AS t1
			LEFT JOIN `deletion_log` AS t2 ON t1.id = t2.asset_id
			LEFT JOIN `mst_plant` AS t3 ON t1.plant = t3.id
			LEFT JOIN `mst_Dep` AS t4 ON t1.department = t4.id
			WHERE delete_atatus = '1'");
		return $query->result_array();
		}else{
			$query = $this->db->query("SELECT t1.id,t1.tag_id,t1.finance_asset_id,t1.it_asset_code,t1.department,t1.plant,t1.asset_user,t2.deletion_by,t2.deletion_at,
			t3.plant_name,t4.dep_name
			FROM mst_assets AS t1
			LEFT JOIN `deletion_log` AS t2 ON t1.id = t2.asset_id
			LEFT JOIN `mst_plant` AS t3 ON t1.plant = t3.id
			LEFT JOIN `mst_Dep` AS t4 ON t1.department = t4.id
			WHERE delete_atatus = '1' AND plant = '".$plant."'");
		return $query->result_array();
		}
		
	}
	
	function Mst_Inventry($loc,$roleid){
		if($roleid =='1'){
			$query = $this->db->query("SELECT t1.inventry_id,t1.tag_id,t1.scan_time,t1.created_at,t1.scan_by,t2.department,t2.plant,t3.plant_name,t4.dep_name
FROM inventry_log AS t1
LEFT JOIN `mst_assets` AS t2 ON t1.tag_id = t2.tag_id
LEFT JOIN `mst_plant` AS t3 ON t2.plant = t3.id
LEFT JOIN `mst_Dep` AS t4 ON t2.department = t4.id
GROUP BY t1.inventry_id ORDER BY t1.id DESC");
		return $query->result_array();
		}else{
		$query = $this->db->query("SELECT t1.inventry_id,t1.tag_id,t1.scan_time,t1.created_at,t1.scan_by,t2.department,t2.plant,t3.plant_name,t4.dep_name
FROM inventry_log AS t1
LEFT JOIN `mst_assets` AS t2 ON t1.tag_id = t2.tag_id
LEFT JOIN `mst_plant` AS t3 ON t2.plant = t3.id
LEFT JOIN `mst_Dep` AS t4 ON t2.department = t4.id
WHERE t2.plant = '".$loc."' GROUP BY t1.inventry_id ORDER BY t1.id DESC");
		return $query->result_array();
		}
	}
	
	function Detailed_inv_session($insession){
		$query = $this->db->query("SELECT t1.id,t1.tag_id,t2.it_asset_code,t2.finance_asset_id,t2.description,t2.asset_user,t1.scan_status,t2.department,t1.scan_time,
(SELECT status_name FROM mst_asset_status WHERE t2.asset_status = mst_asset_status.id) AS status_name, 
(SELECT mst_Dep.dep_name FROM mst_Dep WHERE t2.department = mst_Dep.id) AS depname
FROM inventry_log AS t1
LEFT JOIN mst_assets AS t2 ON t1.tag_id = t2.tag_id 
WHERE t1.inventry_id = '".$insession."'
ORDER BY id DESC LIMIT 5000");
		return $query->result_array();
	}
	
	
	function Search_Mst_Inventry($from,$to,$loc,$roleid){
		if($roleid =='1'){
			$query = $this->db->query("SELECT t1.inventry_id,t1.tag_id,t1.scan_time,t1.created_at,t1.scan_by,t2.department,t2.plant,t3.plant_name,t4.dep_name
FROM inventry_log AS t1
LEFT JOIN `mst_assets` AS t2 ON t1.tag_id = t2.tag_id
LEFT JOIN `mst_plant` AS t3 ON t2.plant = t3.id
LEFT JOIN `mst_Dep` AS t4 ON t2.department = t4.id
WHERE DATE(t1.scan_time) BETWEEN '".$from."' AND '".$to."'
GROUP BY t1.inventry_id
ORDER BY t1.id DESC");
		return $query->result_array();
		}else{
		$query = $this->db->query("SELECT t1.inventry_id,t1.tag_id,t1.scan_time,t1.created_at,t1.scan_by,t2.department,t2.plant,t3.plant_name,t4.dep_name
FROM inventry_log AS t1
LEFT JOIN `mst_assets` AS t2 ON t1.tag_id = t2.tag_id
LEFT JOIN `mst_plant` AS t3 ON t2.plant = t3.id
LEFT JOIN `mst_Dep` AS t4 ON t2.department = t4.id
WHERE t2.plant = '".$loc."' AND DATE(scan_time) BETWEEN '".$from."' AND '".$to."'
GROUP BY t1.inventry_id
ORDER BY t1.id DESC");
		return $query->result_array();
		}
	}
	
}
?>
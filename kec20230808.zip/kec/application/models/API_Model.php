<?php 

class API_Model extends CI_Model
{
	
	function Match_Password($username,$password){
		$query = $this->db->query("SELECT t1.first_name,t1.last_name,t1.user_name,t1.email,t1.mobile_no,t1.emp_code,t1.user_type,t1.site,t1.plant,t2.plant_name
			FROM users AS t1
			LEFT JOIN `mst_plant` AS t2 ON t1.plant = t2.id			
			WHERE t1.user_name = '".$username."' and t1.password = '".$password."'");
		return $query->row();
	}

	function Get_Plant(){
		$query = $this->db->query("select id,plant_name from mst_plant");
		return $query->result_array();
	}

	function Get_Asset_Type(){
		$query = $this->db->query("select id,type_name from mst_asset_type");
		return $query->result_array();
	}

	function Get_Dept(){
		$query = $this->db->query("select id,dep_name from mst_Dep");
		return $query->result_array();
	}

	function Get_Assets($assettype,$plant){
		$query = $this->db->query("SELECT mst_assets.*,
		(SELECT dep_name FROM mst_Dep WHERE mst_Dep.id = mst_assets.department) AS dept_name,
		(SELECT type_name FROM mst_asset_type WHERE mst_asset_type.id = mst_assets.asset_type) AS asset_type_name,
		(SELECT plant_name FROM mst_plant WHERE mst_plant.id = mst_assets.plant) AS plant_name,
		(SELECT location_name FROM mst_location WHERE mst_location.id = mst_assets.location) AS loc_name,
		(SELECT status_name FROM mst_asset_status WHERE mst_asset_status.id = mst_assets.asset_status) AS asset_status
		FROM mst_assets
		WHERE department = '".$assettype."' AND plant = '".$plant."' and delete_atatus = '0'");
		return $query->result_array();
	}

	function Add_Inventry_Log($quary){
		if ($this->db->query("$quary")) {
			return TRUE;
		}else{
			return FALSE;
		}
		
	}

	function Add_Inventry_master($inv_master){
		if ($this->db->query("$inv_master")) {
			return TRUE;
		}else{
			return FALSE;
		}
		
	}

	function Check_transfer_log($tag,$plant){
		$query = $this->db->query("SELECT * FROM asset_transfer_log
		WHERE tagid = '".$tag."' AND source_plant = '".$plant."' AND STATUS = '0'");
		return $query->result_array();

	}

	function Add_TransferTemp($logdata){
		if ($this->db->insert('asset_transfer_log',$logdata)) {
			return TRUE;
		}else{
			return FALSE;
		}
		
	}

	public function batch_data($table, $data){
    $this->db->update_batch($table, $data, 'id'); // this will set the id column as the condition field
    return true;
	}

	function Get_Identify_Data($tag_is){
		$query = $this->db->query("SELECT mst_assets.*,
		(SELECT dep_name FROM mst_Dep WHERE mst_Dep.id = mst_assets.department) AS dept_name,
		(SELECT type_name FROM mst_asset_type WHERE mst_asset_type.id = mst_assets.asset_type) AS asset_type_name,
		(SELECT plant_name FROM mst_plant WHERE mst_plant.id = mst_assets.plant) AS plant_name,
		(SELECT location_name FROM mst_location WHERE mst_location.id = mst_assets.location) AS loc_name,
		(SELECT status_name FROM mst_asset_status WHERE mst_asset_status.id = mst_assets.asset_status) AS asset_status
		FROM mst_assets
		WHERE tag_id = '".$tag_is."' and delete_atatus = '0'");
		return $query->result_array();
	}

	function Get_Tagdata($tid){
		$query = $this->db->query("SELECT id,tag_id,finance_asset_id,it_asset_code,asset_user,plant as source_plant_id,department as source_dept_id,
		(SELECT plant_name FROM mst_plant WHERE mst_plant .id= mst_assets.plant) AS plant_name,
		(SELECT dep_name FROM mst_Dep WHERE mst_Dep.id = mst_assets.department) AS dep_name,
		(SELECT status_name FROM mst_asset_status WHERE mst_asset_status.id = mst_assets.asset_status) AS status_name
		FROM mst_assets WHERE delete_atatus = '0' AND tag_id = '".$tid."'");
		return $query->result_array();
	}

	function Get_Temp_Tagdata($plant){
		$query = $this->db->query("SELECT id,tag_id,finance_asset_id,it_asset_code,asset_user,plant,description,
		(SELECT plant_name FROM mst_plant WHERE mst_plant .id= temp_assets.plant) AS plant_name,
		(SELECT dep_name FROM mst_Dep WHERE mst_Dep.id = temp_assets.department) AS dep_name,
		(SELECT status_name FROM mst_asset_status WHERE mst_asset_status.id = temp_assets.asset_status) AS status_name
		FROM temp_assets WHERE plant = '".$plant."' AND tag_id='0'");
		return $query->result_array();
	}

	function PostData_temp_to_trans($ids){
		if($this->db->query("INSERT INTO mst_assets (tag_id,asset_type,finance_asset_id,sbu,asset_class_1,asset_class_2,asset_sub_class,department,plant,
			make_oem,model,device_sl_no,location,vendor,quantity,it_asset_code,cost_center,po_no,description,asset_user,asset_status,
			purchase_date,capitalized_on,created_by) SELECT tag_id,asset_type,finance_asset_id,sbu,asset_class_1,asset_class_2,asset_sub_class,department,plant,
			make_oem,model,device_sl_no,location,vendor,quantity,it_asset_code,cost_center,po_no,description,asset_user,asset_status,
			purchase_date,capitalized_on,created_by FROM `temp_assets` WHERE id in (".$ids.") and tag_id > '1';
			")){
			$this->db->query("DELETE FROM temp_assets WHERE id in (".$ids.");");
			return TRUE;
		}else{
			return FALSE;
		}
	}


	function Get_approve_transfer_asset($tagid){
		$query = $this->db->query("SELECT tagid,finance_asset_id,it_assetcode,source_plant,source_dept,
		(SELECT plant_name FROM mst_plant WHERE asset_transfer_log.dest_plant =  mst_plant.id) AS descplant ,
		(SELECT dep_name FROM mst_Dep WHERE asset_transfer_log.desc_dept =  mst_Dep.id) AS descdept,
		created_by,created_at 
		FROM asset_transfer_log
		WHERE tagid = '".$tagid."' AND STATUS = '1'");
		return $query->result_array();
	}


}

?>